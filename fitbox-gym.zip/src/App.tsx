import { useState, useEffect } from "react";
import { Dumbbell, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Membership from "./components/Membership";
import Trainers from "./components/Trainers";
import BMICalculator from "./components/BMICalculator";
import Programs from "./components/Programs";
import Gallery from "./components/Gallery";
import Testimonials from "./components/Testimonials";
import Blog from "./components/Blog";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import SEOMeta from "./components/SEOMeta";
import Notification from "./components/Notification";

export default function App() {
  const [dark, setDark] = useState(true);
  const [currentTab, setCurrentTab] = useState("home");
  const [toastMessage, setToastMessage] = useState("");
  const [toastType, setToastType] = useState<"success" | "error" | "info">("success");
  const [isLoading, setIsLoading] = useState(true);

  // Initial loading timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1250);
    return () => clearTimeout(timer);
  }, []);

  // Sync theme to root class
  useEffect(() => {
    const root = window.document.documentElement;
    if (dark) {
      root.classList.add("dark");
      root.style.backgroundColor = "#09090b"; // zinc-950 base
    } else {
      root.classList.remove("dark");
      root.style.backgroundColor = "#f9fafb"; // zinc-50 base
    }
  }, [dark]);

  // Toast automatic dismiss timer
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage("");
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const handleSuccessToast = (msg: string) => {
    setToastType("success");
    setToastMessage(msg);
  };

  const handleHeroNavToSection = (id: string) => {
    setCurrentTab(id);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <>
      {/* Dynamic SEO Meta Configurations */}
      <SEOMeta />

      {/* Premium Full Screen Loading Animation */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-zinc-950 text-white"
            id="global-loader"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, type: "spring" }}
              className="flex flex-col items-center gap-4"
            >
              {/* Rotating Dumbbell Core Icon */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1.8, ease: "linear" }}
                className="w-16 h-16 rounded-2xl bg-lime-500 flex items-center justify-center text-black shadow-xl shadow-lime-500/30 border border-lime-500/20"
              >
                <Dumbbell className="w-8 h-8" />
              </motion.div>
              
              <div className="text-center mt-2.5">
                <span className="font-sans text-2xl font-black uppercase tracking-widest block">
                  Fit<span className="text-lime-500">Box</span>
                </span>
                <span className="text-[10px] font-bold text-zinc-500 tracking-widest uppercase block mt-1">
                  Bengaluru Performance Club
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Website Wrapper */}
      <div className={`min-h-screen text-sans selection:bg-lime-500 selection:text-black transition-colors duration-500 relative overflow-hidden z-0 ${
        dark ? "bg-zinc-950 text-zinc-100" : "bg-zinc-50 text-zinc-900"
      }`}>
        
        {/* Background Mesh Orbs for Frosted Glass theme */}
        <div className="absolute top-[-100px] right-[-100px] w-96 h-96 bg-lime-500/15 rounded-full blur-[120px] pointer-events-none z-0"></div>
        <div className="absolute top-[800px] left-[-100px] w-96 h-96 bg-emerald-500/15 rounded-full blur-[120px] pointer-events-none z-0"></div>
        <div className="absolute top-[2200px] right-10 w-[450px] h-[450px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none z-0"></div>
        <div className="absolute bottom-[200px] left-[-50px] w-80 h-80 bg-lime-500/10 rounded-full blur-[100px] pointer-events-none z-0"></div>
        
        {/* Sticky Translucent Navbar */}
        <Navbar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          dark={dark}
          toggleDark={() => setDark(!dark)}
        />

        {/* Hero Landing Core */}
        <Hero
          dark={dark}
          onJoinClick={() => handleHeroNavToSection("membership")}
          onTrialClick={() => handleHeroNavToSection("contact")}
          onContactClick={() => handleHeroNavToSection("contact")}
        />

        {/* About corporate details */}
        <About dark={dark} />

        {/* Dynamic Services overview */}
        <Services dark={dark} />

        {/* Tiered Membership pricing & registration modals */}
        <Membership dark={dark} onSuccessToast={handleSuccessToast} />

        {/* Certified Instructors sheets */}
        <Trainers dark={dark} />

        {/* Workout interactive plans */}
        <Programs dark={dark} />

        {/* Biometric height/weight calculator */}
        <BMICalculator dark={dark} />

        {/* modern Zoom Lightbox gallery space */}
        <Gallery dark={dark} />

        {/* 280+ Reviews Google Rating sliders */}
        <Testimonials dark={dark} />

        {/* Expandable physical tip blogs */}
        <Blog dark={dark} />

        {/* Collapsible details accordions FAQ */}
        <FAQ dark={dark} />

        {/* Live Map, Call action buttons, and Ticketing Form */}
        <Contact dark={dark} onSuccessToast={handleSuccessToast} />

        {/* Quick Directory links, Newsletter register bar */}
        <Footer dark={dark} onSuccessToast={handleSuccessToast} />

        {/* Smooth spring toast alarms manager */}
        <Notification
          message={toastMessage}
          type={toastType}
          onClose={() => setToastMessage("")}
        />

      </div>
    </>
  );
}
