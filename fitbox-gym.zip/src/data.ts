import { Trainer, MembershipPlan, Service, WorkoutProgram, BlogPost, FAQItem, TestimonialReview } from "./types";
import michaelImg from "./assets/images/trainer_michael_dsouza_1782134363071.jpg";

export const trainersData: Trainer[] = [
  {
    id: "trainer-1",
    name: "Vikram 'The Beast' Gowda",
    role: "Head Strength Coach & Co-founder",
    certs: ["K11 Certified Master Trainer", "IPF Certified Powerlifting Coach", "ESA Sports Nutritionist"],
    experience: "12+ Years",
    specializations: ["Powerlifting", "Hypertrophy Blueprint", "Posture & Spine Alignment"],
    image: "https://images.unsplash.com/photo-1567013127542-490d757e51fc?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "trainer-2",
    name: "Priya Sharma",
    role: "Senior Functional & Cardio Coach",
    certs: ["ACE Personal Trainer Certification", "Zumba® Licensed Instructor", "GGS Women's Pre/Postnatal Fitness"],
    experience: "8+ Years",
    specializations: ["HIIT / Functional Circuit", "Women's Health & Stamina", "Weight Management Nutrition"],
    image: "https://images.unsplash.com/photo-1548690312-e3b507d8c110?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "trainer-3",
    name: "Michael D'Souza",
    role: "Athletic Conditioning Specialist",
    certs: ["NSCA Certified Strength & Conditioning Specialist (CSCS)", "Olympic Weightlifting Level-2 Coach"],
    experience: "10+ Years",
    specializations: ["Explosive Speed & Agility", "Olympic Barbell Complex", "Injury Rehabilitation"],
    image: michaelImg
  },
  {
    id: "trainer-4",
    name: "Sarah Khan",
    role: "Calorific & Fat Loss Expert",
    certs: ["ISSA Certified Fitness Trainer", "Precision Nutrition Level 1 (PN1)", "Kettlebell Athletics Level 2"],
    experience: "6+ Years",
    specializations: ["Metabolic Conditioning", "Kettlebell Workflows", "Habit-Based Coaching & Macros"],
    image: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop"
  }
];

export const membershipPlansData: MembershipPlan[] = [
  {
    id: "plan-monthly",
    name: "Monthly Flex Plan",
    price: 2500,
    period: "Month",
    features: [
      "Access to standardGym Cardio & Strength zones",
      "Locker room & Hot showers available",
      "1 Structured Consultation session with a Trainer",
      "Free high-speed WiFi & mobile charge stations",
      "Valid for 30 consecutive days"
    ],
    highlighted: false,
    tag: "Flexible"
  },
  {
    id: "plan-quarterly",
    name: "Quarterly Starter",
    price: 6500,
    period: "3 Months",
    features: [
      "Full access to strength & cardio zones",
      "1-on-1 Fitness assessment using BMI metrics",
      "Weekly body composition progress charts",
      "Access to standard functional & metabolic classes",
      "15 Days membership freeze facility",
      "Includes general trainer support"
    ],
    highlighted: false,
    tag: "Popular Entry"
  },
  {
    id: "plan-halfyearly",
    name: "Half-Year Transformation",
    price: 11000,
    period: "6 Months",
    features: [
      "All features of Quarterly Starter plan",
      "3 Complimentary intensive Personal Training hours",
      "Personalized monthly nutrition and macro goals",
      "Access to intermediate cardio & CrossFit challenges",
      "30 Days membership freeze facility",
      "Free FitBox shaker bottle premium merchandise"
    ],
    highlighted: true,
    tag: "Highly Recommended"
  },
  {
    id: "plan-annual",
    name: "Elite Performance Annual",
    price: 18000,
    period: "Year",
    features: [
      "Unlimited access to all FitBox facilities & grids",
      "12 Comprehensive 1-on-1 Personal Training sessions",
      "A-Z Customized nutrition dashboard & meal sheets",
      "Priority booking for premium Functional workshops",
      "60 Days total flexible freeze/pause option",
      "Exclusive FitBox Athlete Club Tee & Premium Kit",
      "Unlimited free entry to weekend Guest Masterclasses"
    ],
    highlighted: false,
    tag: "Best Value / Elite Status"
  }
];

export const servicesData: Service[] = [
  {
    id: "srv-weight",
    title: "Weight Training Arena",
    description: "Equipped with world-class dumbbells (up to 50kg), custom bench stations, calibrated steel plates, heavy-duty squat frames, and precise mechanical isolation modules.",
    iconName: "Dumbbell",
    category: "Training"
  },
  {
    id: "srv-cardio",
    title: "Cardio Conditioning Hub",
    description: "Premium self-powered air bikes, elite commercial-grade treadmills, stairmasters, elliptical trainers, and water rowers designed for rapid fat burn and lung capacity.",
    iconName: "Flame",
    category: "Training"
  },
  {
    id: "srv-personal",
    title: "1-on-1 VIP Coaching",
    description: "Tailor-made schedules and constant dynamic guidance to prevent plateaus. Our certified coaches monitor your biometric vitals, posture, and progressive overload.",
    iconName: "User",
    category: "Training"
  },
  {
    id: "srv-strength",
    title: "Power & Olympic Lifts",
    description: "State-of-the-art solid wood lifting platforms, elite competition barbells, bumper plates, and magnesium chalk buckets for flawless deadlifts and power cleans.",
    iconName: "Zap",
    category: "Training"
  },
  {
    id: "srv-fatloss",
    title: "Fat Loss Specialization",
    description: "Metabolic rate optimization merging high-volume conditioning with high-intensity interval metrics to burn calories long after you have completed your day's work.",
    iconName: "TrendingDown",
    category: "Program"
  },
  {
    id: "srv-muscle",
    title: "Hypertrophy Mastery",
    description: "Scientifically structured volume splits, mechanical tension optimization, and time-under-tension drills engineered specifically for localized biological recovery.",
    iconName: "ShieldAlert",
    category: "Program"
  },
  {
    id: "srv-nutrition",
    title: "Macro & Meal Blueprinting",
    description: "Ditch the crash diets. Receive a personalized calculated breakdown of your energy thresholds, including exact macros, grocery list, and meal timings.",
    iconName: "Apple",
    category: "Nutrition"
  },
  {
    id: "srv-group",
    title: "High-Energy Group Circuits",
    description: "Push matching peers in rapid fitness drills comprising HIIT stations, battle ropes, slamball relays, and energetic cooperative endurance metrics.",
    iconName: "Users",
    category: "Training"
  },
  {
    id: "srv-functional",
    title: "Functional Calisthenics",
    description: "TRX suspension bands, heavy sandbags, target wallboards, plyometric block steps, and kettlebell flow grids focusing on everyday organic movement and agility.",
    iconName: "Activity",
    category: "Training"
  }
];

export const workoutProgramsData: WorkoutProgram[] = [
  {
    id: "prog-beginner",
    name: "Beginner Restoration Program",
    duration: "4 Weeks",
    intensity: "Beginner",
    objective: "Establish basic joint stability, cardiovascular base, and core physical posture.",
    description: "Perfect for active first-timers looking to build self-confidence, correct range of motion on core lifts, and transition safely into heavier progressive overload grids.",
    schedule: [
      {
        day: "Monday (Push Focus)",
        routine: "Chest & Shoulders Basic Mobilization",
        exercises: ["Incline DB Chest Press (3x12)", "Dumbbell Lateral Raises (3x15)", "Supported Seated Machine Press (3x10)", "Plank Core Hold (3x45s)"]
      },
      {
        day: "Wednesday (Pull Focus)",
        routine: "Back & Bicep Mechanics",
        exercises: ["Lat Pulldowns (3x12)", "Supported Machine Row (3x10)", "DB Alternate curls (3x12)", "Hyperextensions for glutes (3x12)"]
      },
      {
        day: "Friday (Legs & Cardio)",
        routine: "Lower Body Range of Motion",
        exercises: ["Goblet Squats with KB (3x10)", "Lying Leg Curl (3x12)", "Calf Raises on platform (3x15)", "15 mins LISS Treadmill Steady Walking"]
      }
    ]
  },
  {
    id: "prog-intermediate",
    name: "Intermediate Push-Pull-Legs Split",
    duration: "8 Weeks",
    intensity: "Intermediate",
    objective: "Maximize compound strength, localized hypertrophy, and target power gains.",
    description: "Designed for steady lifters who already know correct lifting posture and want to increase compound muscle density or handle heavier barbell numbers safely.",
    schedule: [
      {
        day: "Mon / Thu (Push Split)",
        routine: "Upper Body Horizontal & Vertical Push",
        exercises: ["Barbell Flat Bench Press (4x8)", "Overhead Barbell Military Press (3x8)", "DB Incline Chest Flyes (3x12)", "Dips / Rope Tricep Extensions (4x10)"]
      },
      {
        day: "Tue / Fri (Pull Split)",
        routine: "Horizontal Thickness & Lat Expansion",
        exercises: ["Conventional Deadlifts (3x5)", "Weighted Lat Pullups (4x6)", "Chest Supported DB Rows (3x10)", "Incline DB Hammer Curl (3x12)"]
      },
      {
        day: "Wed / Sat (Legs Split)",
        routine: "Full Lower Quadrant Drive",
        exercises: ["Barbell Back Squat (4x8)", "Romanian Deadlift (4x10)", "Bulgarian Split Squat (3x12 each)", "Standing Calf Raise (4x15)"]
      }
    ]
  },
  {
    id: "prog-advanced",
    name: "Advanced Hypertrophy & Athlete Core",
    duration: "12 Weeks",
    intensity: "Advanced",
    objective: "Simultaneous skeletal mass accumulation, central nervous system conditioning.",
    description: "A professional-level program focusing on high-volume periodized routines, dropsets, and high neuromuscular engagement. High recovery compliance required.",
    schedule: [
      {
        day: "Day 1 (Chest & Upper Back)",
        routine: "Agonist-Antagonist Giant Supersets",
        exercises: ["Incline Barbell Bench superset with Chest Supported Rows (5x8)", "Flat DB Press superset with Lat Pullups (4x10)", "Cable Pec Crossovers superset with Face Pulls (3x15)"]
      },
      {
        day: "Day 2 (Lower Quad Focus & Hams)",
        routine: "Maximum Volume Compound Load",
        exercises: ["Barbell Squat (5x5 Heavier)", "Deficit Deadlifts (4x8)", "Leg Extensions - Triple Dropset (3x10 reps)", "Hamstring Curl - 5s negative accent (4x10)"]
      },
      {
        day: "Day 3 (Shoulder Caps & Arms)",
        routine: "3D Deltoid & Arm Hypertrophy",
        exercises: ["Seated Overhead Dumbbell Press (4x8)", "Leaning Cable Lateral Raise (4x12)", "Seated DB incline curl superset with EZ Bar Tricep Crushers (4x10)"]
      }
    ]
  },
  {
    id: "prog-weightloss",
    name: "Metabolic Calorie Crusher Flow",
    duration: "6 Weeks",
    intensity: "Intermediate",
    objective: "Sustained post-workout oxygen consumption (EPOC), core fat oxidation.",
    description: "Combines functional resistance compounds with bodyweight cardio intervals to maximize calories spent during and up to 24 hours after your gym session.",
    schedule: [
      {
        day: "Mon / Wed / Fri (HIIT Circuit)",
        routine: "Full-Body Agility & Resistance",
        exercises: ["Kettlebell Swings (45s work / 15s rest)", "Burpee Tuck jumps (45s work / 15s rest)", "Slam ball slams (45s work / 15s rest)", "Battle rope dual waves (4x60s)"]
      },
      {
        day: "Tue / Thu (LISS & Core)",
        routine: "Steady State Fat Burning Flow",
        exercises: ["Treadmill Incline Hike- 8% at 5.5 km/hr (35 mins)", "Hanging Leg Raises (4x15)", "Russian Twists with Med Ball (4x25)", "Prone Cobra Holds (3x60s)"]
      }
    ]
  },
  {
    id: "prog-musclegain",
    name: "Max Density Muscle Mass Spec",
    duration: "10 Weeks",
    intensity: "Advanced",
    objective: "Stimulate myofibrillar synthesis and support lean muscle enlargement.",
    description: "Focuses on high mechanical fatigue, controlled tempo (3-second eccentric release), and mandatory clean caloric surplus tracking (diet charts included).",
    schedule: [
      {
        day: "Mon (Heavy Compound Pull)",
        routine: "Back Width & Thickness Focus",
        exercises: ["Weighted Chin-ups (4x6)", "Heavy T-Bar Rows (4x8)", "Stiff Legged Deadlifts (4x10)", "EZ Bar Cheat Curls (3x8)"]
      },
      {
        day: "Wed (Heavy Compound Push)",
        routine: "Pectoral & Deltoid Enlargement",
        exercises: ["Heavy DB Flat Press (4x6)", "Decline Barbell Press (3x8)", "Seated Overhead Dumbbell Press (4x8)", "Barbell Skullcrushers (3x10)"]
      },
      {
        day: "Fri (Heavy Compound Leg Split)",
        routine: "Quad, Glute & Adductor Overdrive",
        exercises: ["Barbell Safety squats (4x8)", "Leg Press - progressive loading (4x10)", "Lying leg curls (3x12)", "Standing DB Calf Raises (4x15)"]
      }
    ]
  }
];

export const testimonialsData: TestimonialReview[] = [
  {
    id: "rev-1",
    name: "Pranav Gowda",
    rating: 5,
    comment: "FitBox is undoubtedly the best gym around Kadugondanahalli area! The trainers here, especially Coach Vikram, are extremely knowledgeable. They don't just tell you what to do, they explain the biomechanics behind the exercises. Standard of machinery is top-notch.",
    date: "2 weeks ago",
    tag: "Bodybuilding Member"
  },
  {
    id: "rev-2",
    name: "Aishwarya R.",
    rating: 5,
    comment: "I joined the 6-month transformation program for fat loss and the results have been incredible. Priya Ma'am tailored my diet plan based on local South Indian food availability, making it super easy to follow. Extremely clean locker rooms and professional crowd.",
    date: "1 month ago",
    tag: "Transformation Success"
  },
  {
    id: "rev-3",
    name: "Rehan Ahmed",
    rating: 5,
    comment: "Clean, spacious, and amazing vibe. They have heavy commercial treadmills, rowers, and dynamic battle ropes which I love. The quarterly plan feels very economical for the quality of workout environments you receive. Solid 5/5 stars from my side!",
    date: "1 month ago",
    tag: "Functional Enthusiast"
  },
  {
    id: "rev-4",
    name: "Sowmya Murthy",
    rating: 4,
    comment: "Staff is highly encouraging and helpful. I was intimidated to start weightlifting but Michael guided me patiently through standard deadlifts and overhead barbell actions. The community supports each other highly warmly. Parking gets a bit busy during 7 PM, but managed.",
    date: "3 weeks ago",
    tag: "Beginner Lifter"
  },
  {
    id: "rev-5",
    name: "Aniket Sen",
    rating: 5,
    comment: "Excellent range of dumbbells and multiple squat racks so we rarely have to wait. They maintain high cleanliness standards. The annual plan is ridiculously good value considering they give personal training credits and high-quality premium merch with it.",
    date: "2 months ago",
    tag: "Elite Athlete Club"
  },
  {
    id: "rev-6",
    name: "Deepak Krishnan",
    rating: 5,
    comment: "Joined three months back and lost 8 kgs. The trainers keep pushing you with progressive goals. Best gym opposite Krishna Leela Grand. Highly professional, responsive staff. Love the community vibe on weekends!",
    date: "3 months ago",
    tag: "Cardio Focus"
  }
];

export const blogPostsData: BlogPost[] = [
  {
    id: "blog-1",
    title: "The Ultimate Guide to Hypertrophy: How Bengaluru Gym Goers Make Real Gains",
    excerpt: "Ditch the junk volume. Learn the scientific principles of progressive overload, optimal muscle mechanical tension, and local recovery routines.",
    content: `Hypertrophy occurs when muscle fibers undergo mechanical tension under controlled resistance. Many gym-goers in Bengaluru fall into the trap of doing too many 'junk sets' without progressive overload. To build dense, lean skeletal muscle at FitBox Gym, stick to these core guidelines:

1. **Focus on Progressive Overload**: If you lifted 20kg dumbbells for 8 reps last week, try to lift 22.5kg for 8 reps, or the same 20kg for 9-10 reps this week. Keep detailed logs!
2. **Control the Eccentric Tempo**: Do not let gravity drop the weights. Lower the bar slowly (2 to 3 seconds) to create maximum micro-tears in the target tissue.
3. **Train Close to Failure**: Your final 2 sets on a target muscle should be within 1-2 reps of technical failure. This stimulates the central nervous system to trigger localized hypertrophy factors.
4. **Prioritize local rest**: Muscle tissue doesn't grow in the gym; it grows while you sleep. Aim for 7.5 to 9 hours of quality sleep every night.`,
    category: "Muscle Building",
    date: "June 15, 2026",
    image: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop",
    author: "Head Coach Vikram Gowda",
    readTime: "4 min read"
  },
  {
    id: "blog-2",
    title: "5 Local Superfoods to Fuel Your Intense Bengaluru Workouts",
    excerpt: "No need for exotic, expensive imports. Fuel your gym transformations with readily available, highly affordable local ingredients.",
    content: `Many fitness influencers recommend expensive exotic seeds and imported berries. However, local Bengaluru markets contain exceptional, bio-available options that fuel peak dynamic performance:

1. **Ragi (Finger Millet)**: Rich in calcium, amino acids, and complex carbohydrates. Consuming ragi mudde or a ragi malt smoothie 2 hours before dynamic push-pull-legs routines ensures sustained glycogen levels with zero insulin spikes.
2. **Sattu (Roasted Gram Flour)**: A vegan powerhouse offering high premium plant protein and cooling benefits. Drinking sattu mixed in buttermilk after intense HIIT serves as a flawless natural recovery shake.
3. **Paneer & Curd**: Raw, locally unsalted paneer offers dense casein proteins, keeping your body in an anabolic recovery state overnight. Unsweetened curd acts as a natural probiotic to improve digestion.
4. **Jackfruit Seeds**: Packed with complex copper minerals, fiber, and resistant starch, roasted jackfruit seeds serve as the perfect slow-digesting evening snack for muscle recovery.
5. **Local Bananas (Yelakki)**: Instant natural potassium and glucose source to stave off sudden muscle cramps during peak summer barbell compounds.`,
    category: "Nutrition Guidance",
    date: "June 08, 2026",
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=600&auto=format&fit=crop",
    author: "Coach Priya Sharma",
    readTime: "5 min read"
  },
  {
    id: "blog-3",
    title: "Common Squat Mistakes and How to Correct Them Instantly",
    excerpt: "Avoid knee valgus, lower back rounding, and partial squat traps. Form is everything when managing heavier olympic steel plates.",
    content: `The squat is the king of lower quadrant exercises. Yet, poor form frequently limits progress or leads to lower back and knee discomfort. Here is how to correct the three most dangerous errors we see on the gym floor:

1. **Mistake 1: 'Butt Wink' (Lower Back Curvature)**: This occurs when your pelvis tucks under at the bottom of the squat, stretching spinal discs.
   * *The Fix*: Stop squatting deeper than your active hamstring flexibility allows. Focus on bracing your abs and pushing your hips back as if sitting on a low stool.
2. **Mistake 2: 'Knee Valgus' (Knees Caving Inward)**: As you drive upwards, your knees collapse toward each other. This strains the ACL.
   * *The Fix*: Wrap a light resistance feedback band around your calves and actively push your knees outward against the band during warmups. Focus on driving through your pinky toes.
3. **Mistake 3: 'Half-Squatting' (Insufficient Depth)**: Stopping short of parallel heavily minimizes glute and hamstring activation, while overloading knee patella tendons.
   * *The Fix*: Drop the weight by 30%. Practice pausing squat reps at parallel depth (hip crease aligned with knee cap) before driving upwards.`,
    category: "Lifting Form",
    date: "May 28, 2026",
    image: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=600&auto=format&fit=crop",
    author: "Coach Michael D'Souza",
    readTime: "3 min read"
  }
];

export const faqData: FAQItem[] = [
  {
    id: "faq-1",
    question: "What are the timings of FitBox Gym Bengaluru?",
    answer: "We are open from Monday to Saturday, 5:00 AM to 10:00 PM to support both early-morning professionals and late-night workers. On Sundays, we are open in a shortened window from 7:00 AM to 2:00 PM for general maintenance and flexible weekend routines."
  },
  {
    id: "faq-2",
    question: "Do you offer parking facilities?",
    answer: "Yes, we have designated, secured parking spaces for both two-wheelers and four-wheelers directly in front of the building. Parking is fully free of charge for active FitBox members."
  },
  {
    id: "faq-3",
    question: "Can I pause or freeze my membership during travels?",
    answer: "Absolutely. We understand travel schedules. You can freeze your Quarterly plan for up to 15 days, your Half-Yearly plan for up to 30 days, and your Annual plan for up to 60 days total. Simply notify us via email or WhatsApp 48 hours prior to freezing."
  },
  {
    id: "faq-4",
    question: "Is personal training included in standard plans?",
    answer: "Each membership package starts with a free biometric assessment, goal setting, and a personalized 1-day gym guide. Full-scale 1-on-1 personal training can be booked separately, or redeemed as a complimentary package of 12 sessions under our Annual membership."
  },
  {
    id: "faq-5",
    question: "Are showers, locker systems, and drinking water available?",
    answer: "Yes! FitBox features sanitized, premium changing rooms equipped with high-pressure hot water showers, private lockers, and multiple RO filtered drinking stations to keep you fresh and hydrated."
  },
  {
    id: "faq-6",
    question: "Where are you located in Bengaluru?",
    answer: "We are conveniently located at: 3rd H Main Rd, opposite Krishna Leela Grand Hotel, St Thomas Town, Kadugondanahalli, Bengaluru, Karnataka 560084. You can find us opposite the iconic restaurant on the third floors."
  }
];
