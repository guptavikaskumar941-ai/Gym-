import { useState } from "react";
import { workoutProgramsData } from "../data";
import { WorkoutProgram } from "../types";
import { Calendar, Dumbbell, Clock, Gauge, ClipboardCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ProgramsProps {
  dark: boolean;
}

export default function Programs({ dark }: ProgramsProps) {
  const [activeProgramId, setActiveProgramId] = useState<string>("prog-beginner");

  const activeProgram = workoutProgramsData.find((p) => p.id === activeProgramId) || workoutProgramsData[0];

  return (
    <section
      id="plans"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title block */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Dynamic Training Logs
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Tailored Workout Routines
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Explore our foundational schedules. Toggle between different intensity scopes below to reveal tailored daily barbell routines and targeted exercises.
          </p>
        </div>

        {/* Horizontal Navigation List */}
        <div className="flex overflow-x-auto pb-4 gap-2 scrollbar-none justify-start md:justify-center mb-12" id="program-tags">
          {workoutProgramsData.map((p) => {
            const isSelected = p.id === activeProgramId;
            return (
              <button
                key={p.id}
                onClick={() => setActiveProgramId(p.id)}
                className={`px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold tracking-wide uppercase border transition-all duration-300 flex-shrink-0 flex items-center gap-2 pointer-events-auto backdrop-blur-md ${
                  isSelected
                    ? "bg-lime-500 border-lime-500 text-black shadow-lg shadow-lime-500/20"
                    : dark
                      ? "bg-white/5 border-white/10 text-zinc-350 hover:bg-white/10"
                      : "bg-black/5 border-black/10 text-zinc-650 hover:bg-black/10"
                }`}
              >
                <Dumbbell className={`w-4 h-4 ${isSelected ? "text-black" : "text-lime-400"}`} />
                {p.name.replace(" Program", "").replace(" Split", "").replace(" Flow", "").replace(" Spec", "")}
              </button>
            );
          })}
        </div>

        {/* Active Program View panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left" id="program-view-display">
          {/* Card Left: Target Objectives & Details */}
          <div className={`p-6 sm:p-8 rounded-3xl border lg:col-span-4 flex flex-col justify-between h-full backdrop-blur-xl ${
            dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
          }`}>
            <div>
              {/* Intensity block badge */}
              <div className="flex items-center gap-2.5 mb-6" id={`prog-head-${activeProgram.id}`}>
                <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                  activeProgram.intensity === "Beginner"
                    ? "bg-green-550/10 text-green-400 border border-green-500/20"
                    : activeProgram.intensity === "Intermediate"
                      ? "bg-amber-550/10 text-amber-400 border border-amber-500/20"
                      : "bg-red-550/10 text-red-400 border border-red-500/20"
                }`}>
                  {activeProgram.intensity} Level
                </span>
                <div className="flex items-center gap-1 text-zinc-500 text-xs font-bold uppercase tracking-wider">
                  <Clock className={`w-3.5 h-3.5 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                  <span>{activeProgram.duration}</span>
                </div>
              </div>

              <h3 className={`font-sans text-xl sm:text-2xl font-black uppercase tracking-tight mb-3 ${
                dark ? "text-white" : "text-zinc-900"
              }`}>
                {activeProgram.name}
              </h3>

              <p className={`text-xs sm:text-sm leading-relaxed mb-6 font-semibold ${
                dark ? "text-zinc-400" : "text-zinc-650"
              }`}>
                {activeProgram.description}
              </p>
            </div>

            <div className="border-t border-zinc-850/10 dark:border-white/5 pt-6 space-y-4">
              <div>
                <div className="flex items-center gap-1.5 mb-1.5">
                  <ClipboardCheck className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  <span className={`text-[10px] font-black uppercase tracking-widest ${dark ? "text-lime-400" : "text-lime-600"}`}>Target Objective</span>
                </div>
                <p className={`text-xs font-semibold leading-relaxed ${dark ? "text-zinc-300" : "text-zinc-700"}`}>
                  {activeProgram.objective}
                </p>
              </div>
            </div>
          </div>

          {/* Card Right: Custom Schedule Logs Grid */}
          <div className="lg:col-span-8 space-y-4" id="program-schedule-container">
            <h4 className={`text-xs font-black uppercase tracking-widest ${dark ? "text-zinc-400" : "text-zinc-500"}`}>
              Standard Weekly Schedule Splits:
            </h4>
            
            <div className="space-y-4">
              {activeProgram.schedule.map((sch, idx) => (
                <div
                  key={sch.day}
                  className={`p-6 rounded-2xl border transition-all flex flex-col md:flex-row justify-between gap-6 backdrop-blur-xl ${
                    dark ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-black/5 border-black/10 hover:bg-black/10"
                  }`}
                >
                  {/* Left day sub header */}
                  <div className="md:w-1/3 border-b md:border-b-0 md:border-r border-zinc-200/50 dark:border-zinc-850/65 pb-4 md:pb-0 md:pr-4">
                    <div className={`flex items-center gap-1 font-extrabold text-sm sm:text-base uppercase tracking-wider mb-1 ${dark ? "text-lime-400" : "text-lime-600"}`}>
                      <Calendar className="w-4.5 h-4.5" />
                      <span>{sch.day.split(" ")[0]}</span>
                    </div>
                    <span className={`text-[11px] font-black uppercase tracking-widest text-zinc-450`}>
                      {sch.day.includes("(") ? sch.day.split("(")[1].replace(")", "") : "Active Focus"}
                    </span>
                    <p className={`text-xs font-black uppercase mt-2 ${dark ? "text-white" : "text-zinc-900"}`}>
                      {sch.routine}
                    </p>
                  </div>

                  {/* Right: exercise details */}
                  <div className="md:w-2/3 space-y-2">
                    <span className={`text-[10px] font-black uppercase tracking-widest block mb-2 ${dark ? "text-lime-400" : "text-lime-600"}`}>
                      Target Rep Movements & Sets:
                    </span>
                    <ul className="space-y-2 text-xs font-semibold">
                      {sch.exercises.map((ex) => (
                        <li key={ex} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-lime-500 mt-1.5 flex-shrink-0" />
                          <span className={dark ? "text-zinc-300" : "text-zinc-700"}>{ex}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
