import { useState } from "react";
import { trainersData } from "../data";
import { Trainer } from "../types";
import { Award, Briefcase, GraduationCap, ChevronDown, ChevronUp, Instagram, Twitter } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface TrainersProps {
  dark: boolean;
}

export default function Trainers({ dark }: TrainersProps) {
  const [activeTrainerCard, setActiveTrainerCard] = useState<string | null>(null);

  const toggleTrainerDetails = (id: string) => {
    setActiveTrainerCard(activeTrainerCard === id ? null : id);
  };

  return (
    <section
      id="trainers"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Physical Architects
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Our Certified Instructors
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            We strictly do not hire 'exercise monitors'. Every trainer at FitBox Bengaluru is a fully licensed biometric professional, bound by high-standard science protocols.
          </p>
        </div>

        {/* Trainers Grid Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trainersData.map((trainer) => {
            const isExpanded = activeTrainerCard === trainer.id;
            return (
              <div
                key={trainer.id}
                className={`rounded-2xl overflow-hidden border transition-all duration-350 flex flex-col justify-between backdrop-blur-xl ${
                  dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
                }`}
                id={`trainer-card-${trainer.id}`}
              >
                {/* Trainer Portrait with overlay */}
                <div className="relative aspect-[4/5] w-full overflow-hidden group">
                  <img
                    referrerPolicy="no-referrer"
                    src={trainer.image}
                    alt={trainer.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Visual Shadow Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent flex flex-col justify-end p-5 text-left">
                    <span className="text-[10px] font-black uppercase tracking-widest text-lime-450">
                      {trainer.role}
                    </span>
                    <h3 className="font-sans text-xl font-bold text-white uppercase tracking-tight mt-0.5 leading-none">
                      {trainer.name}
                    </h3>
                  </div>
                </div>

                {/* Trainer Meta Fields */}
                <div className="p-5 flex-1 flex flex-col justify-between text-left">
                  <div>
                    {/* Experience Banner */}
                    <div className="flex items-center gap-1.5 mb-3.5" id={`trainer-exp-${trainer.id}`}>
                      <Briefcase className={`w-4 h-4 flex-shrink-0 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                      <span className={`text-xs font-bold uppercase tracking-wider ${dark ? "text-zinc-350" : "text-zinc-650"}`}>
                        Experience: {trainer.experience}
                      </span>
                    </div>

                    {/* Certifications and Specializations */}
                    <button
                      onClick={() => toggleTrainerDetails(trainer.id)}
                      className={`w-full py-2.5 px-3 rounded-xl border text-xs font-black uppercase tracking-wider flex items-center justify-between transition-colors pointer-events-auto ${
                        dark
                          ? "bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10"
                          : "bg-black/5 border-black/10 text-zinc-700 hover:bg-black/10"
                      }`}
                    >
                      <span>Show licenses</span>
                      {isExpanded ? (
                        <ChevronUp className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                      ) : (
                        <ChevronDown className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                      )}
                    </button>

                    {/* Animated Collapsible Tray */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden mt-3 text-xs"
                        >
                          {/* Qualifications Accordion Panel */}
                          <div className={`p-3.5 rounded-xl border space-y-3 backdrop-blur-md ${
                            dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10"
                          }`}>
                            <div>
                              <div className="flex items-center gap-1.5 mb-1.5">
                                <GraduationCap className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                                <span className={`font-bold uppercase tracking-wide ${dark ? "text-lime-450" : "text-lime-600"}`}>Licenses</span>
                              </div>
                              <ul className="space-y-1 list-none pl-0">
                                {trainer.certs.map((cert) => (
                                  <li key={cert} className={`text-[11px] font-semibold ${dark ? "text-zinc-400" : "text-zinc-600"}`}>
                                    • {cert}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div>
                              <div className="flex items-center gap-1.5 mb-1.5">
                                <Award className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                                <span className={`font-bold uppercase tracking-wide ${dark ? "text-lime-450" : "text-lime-600"}`}>Specializations</span>
                              </div>
                              <div className="flex flex-wrap gap-1">
                                {trainer.specializations.map((spec) => (
                                  <span
                                    key={spec}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                      dark ? "bg-zinc-800 text-zinc-300" : "bg-zinc-200 text-zinc-700"
                                    }`}
                                  >
                                    {spec}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Social Handles Icons */}
                  <div className="flex justify-start gap-3 border-t border-zinc-800/10 dark:border-white/5 mt-4 pt-3">
                    <a
                      href="#trainers"
                      className={`p-1.5 rounded hover:bg-lime-500/10 hover:text-lime-400 transition-colors ${
                        dark ? "text-zinc-455" : "text-zinc-400"
                      }`}
                      aria-label={`${trainer.name} Instagram`}
                    >
                      <Instagram className="w-4.5 h-4.5" />
                    </a>
                    <a
                      href="#trainers"
                      className={`p-1.5 rounded hover:bg-lime-500/10 hover:text-lime-400 transition-colors ${
                        dark ? "text-zinc-455" : "text-zinc-400"
                      }`}
                      aria-label={`${trainer.name} Twitter`}
                    >
                      <Twitter className="w-4.5 h-4.5" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
