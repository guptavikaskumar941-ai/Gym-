import { X, CheckCircle, AlertCircle, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NotificationProps {
  message: string;
  type: "success" | "error" | "info";
  onClose: () => void;
}

export default function Notification({ message, type, onClose }: NotificationProps) {
  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          className="fixed bottom-6 right-6 z-50 max-w-sm w-full shadow-2xl rounded-2xl overflow-hidden border bg-zinc-950 border-zinc-800 text-white"
        >
          <div className="p-4.5 flex items-start gap-3.5 text-left">
            {/* Dynamic Status Icons */}
            <div className="flex-shrink-0 mt-0.5" id="toast-status-icon">
              {type === "success" && <CheckCircle className="w-5 h-5 text-emerald-500 animate-pulse" />}
              {type === "error" && <AlertCircle className="w-5 h-5 text-rose-500" />}
              {type === "info" && <Info className="w-5 h-5 text-sky-500" />}
            </div>

            {/* Notification contents text */}
            <div className="flex-1" id="toast-text-group">
              <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">
                SYSTEM MESSAGE
              </p>
              <p className="text-xs sm:text-sm font-semibold tracking-wide text-zinc-200 mt-0.5 leading-relaxed">
                {message}
              </p>
            </div>

            {/* Manual exit button */}
            <button
              onClick={onClose}
              className="flex-shrink-0 rounded-lg p-1 hover:bg-zinc-900 text-zinc-400 hover:text-white transition pointer-events-auto"
              aria-label="Dismiss message panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          
          {/* Animated visual progress timer bar */}
          <motion.div
            initial={{ width: "100%" }}
            animate={{ width: "0%" }}
            transition={{ duration: 5, ease: "linear" }}
            className={`h-1 ${
              type === "success" ? "bg-lime-500" : type === "error" ? "bg-rose-500" : "bg-sky-500"
            }`}
            id="toast-liner"
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
