import { useState } from "react";
import { servicesData } from "../data";
import { Service } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { Dumbbell, Flame, User, Zap, TrendingDown, Target, Apple, Users, Activity } from "lucide-react";

interface ServicesProps {
  dark: boolean;
}

// Icon mapping function to load clean React elements dynamically
const ServiceIcon = ({ name, className }: { name: string; className: string }) => {
  switch (name) {
    case "Dumbbell":
      return <Dumbbell className={className} />;
    case "Flame":
      return <Flame className={className} />;
    case "User":
      return <User className={className} />;
    case "Zap":
      return <Zap className={className} />;
    case "TrendingDown":
      return <TrendingDown className={className} />;
    case "ShieldAlert":
      return <Target className={className} />;
    case "Apple":
      return <Apple className={className} />;
    case "Users":
      return <Users className={className} />;
    case "Activity":
      return <Activity className={className} />;
    default:
      return <Dumbbell className={className} />;
  }
};

export default function Services({ dark }: ServicesProps) {
  const [filter, setFilter] = useState<"All" | "Training" | "Program" | "Nutrition">("All");

  const categories = [
    { value: "All", label: "All Services" },
    { value: "Training", label: "Specialist Training" },
    { value: "Program", label: "Hypertrophy & Loss Programs" },
    { value: "Nutrition", label: "Nutrition & Diet" },
  ];

  const filteredServices = servicesData.filter((item) => {
    if (filter === "All") return true;
    return item.category === filter;
  });

  return (
    <section
      id="services"
      className={`py-24 transition-colors duration-500 relative z-10 border-t border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Title Grid */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-xl">
            <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
              Elite Specializations
            </span>
            <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
              dark ? "text-white" : "text-zinc-900"
            }`}>
              What We Excel In
            </h2>
            <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
              dark ? "text-zinc-400" : "text-zinc-650"
            }`}>
              Our comprehensive gym ecosystem covers tactical physical hypertrophy, high-efficiency metabolic cardiac conditioning, and custom bio-nutrition mapping under one unified roof.
            </p>
          </div>

          {/* Filter Pill Tabs */}
          <div className="flex flex-wrap gap-2" id="services-tabs-container">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setFilter(cat.value as any)}
                className={`px-4 py-2 text-xs sm:text-sm font-bold tracking-wide uppercase rounded-xl border transition-all duration-300 pointer-events-auto ${
                  filter === cat.value
                    ? "bg-lime-500 border-lime-500 text-black shadow-md shadow-lime-500/20"
                    : dark
                      ? "bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10 hover:text-white"
                      : "bg-black/5 border-black/10 text-zinc-650 hover:bg-black/10 hover:text-zinc-900px"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Services Bento Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          id="services-grid"
        >
          <AnimatePresence mode="popLayout">
            {filteredServices.map((srv, index) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -15 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                key={srv.id}
                className={`p-8 rounded-2xl border transition-all duration-300 flex flex-col justify-between group h-full backdrop-blur-xl ${
                  dark
                    ? "bg-white/5 border-white/15 hover:border-lime-500/30 text-white shadow hover:shadow-lg shadow-black/30"
                    : "bg-black/5 border-black/15 hover:border-lime-650/30 text-zinc-900 shadow hover:shadow-lg shadow-zinc-100"
                }`}
              >
                <div>
                  {/* Service Icon with animated accent */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 border ${
                    dark ? "bg-white/5 border-white/10 text-lime-400 group-hover:bg-lime-500/10" : "bg-black/5 border-black/10 text-lime-600 group-hover:bg-lime-650/10"
                  }`}>
                    <ServiceIcon name={srv.iconName} className="w-6 h-6" />
                  </div>

                  <h3 className="font-sans text-lg font-black uppercase tracking-wide mb-3">
                    {srv.title}
                  </h3>

                  <p className={`text-xs sm:text-sm leading-relaxed mb-6 font-semibold ${
                    dark ? "text-zinc-400" : "text-zinc-650"
                  }`}>
                    {srv.description}
                  </p>
                </div>

                <div className={`flex items-center gap-1.5 text-xs font-black uppercase tracking-wider group-hover:gap-2.5 transition-all duration-300 ${
                  dark ? "text-lime-400" : "text-lime-600"
                }`}>
                  <span>Learn Training Spec</span>
                  <span>→</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

      </div>
    </section>
  );
}
