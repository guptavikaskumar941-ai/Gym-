import React, { useState } from "react";
import { ZoomIn, ChevronLeft, ChevronRight, X, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GalleryProps {
  dark: boolean;
}

interface GalleryImage {
  id: string;
  url: string;
  title: string;
  category: "Equipments" | "Amenities" | "Training Zones";
  desc: string;
}

export default function Gallery({ dark }: GalleryProps) {
  const [activeImageIdx, setActiveImageIdx] = useState<number | null>(null);

  const images: GalleryImage[] = [
    {
      id: "gym-img-1",
      url: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=800&auto=format&fit=crop",
      title: "Leg Press & Squat Matrix",
      category: "Equipments",
      desc: "Premium linear-bearing leg press and ultra-reinforced competition squat pegs for deep quad activation.",
    },
    {
      id: "gym-img-2",
      url: "https://images.unsplash.com/photo-1637666062717-1c6bcab4a4ed?q=80&w=800&auto=format&fit=crop",
      title: "Calibrated Steel Dumbbell Rack",
      category: "Equipments",
      desc: "Full roster of solid rubber dumbbells ranging from 2.5kg up to 50kg, aligned with heavy duty bench setups.",
    },
    {
      id: "gym-img-3",
      url: "https://images.unsplash.com/photo-1548690312-e3b507d8c110?q=80&w=800&auto=format&fit=crop",
      title: "Functional Calisthenics Core Zone",
      category: "Training Zones",
      desc: "Shock-absorbing rubber athletic sports turf containing kettlebells, heavy slam balls, and battling ropes.",
    },
    {
      id: "gym-img-4",
      url: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=800&auto=format&fit=crop",
      title: "Adjustable Double Cable Pulley",
      category: "Equipments",
      desc: "Smooth magnetic dual columns with interchangeable grips for chest cable flys and tricep pushdowns.",
    },
    {
      id: "gym-img-5",
      url: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?q=80&w=800&auto=format&fit=crop",
      title: "Sanitized Premium Locker Changing Units",
      category: "Amenities",
      desc: "Highly-ventilated wooden personal locker cabinets, keyless dial entry locks, and high-pressure steam showers.",
    },
    {
      id: "gym-img-6",
      url: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=800&auto=format&fit=crop",
      title: "Aerobic Conditioning Rows",
      category: "Training Zones",
      desc: "Commercial state-of-the-art treadmills, fluid rowers, and air bikes optimized with biometric screen readouts.",
    },
  ];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeImageIdx !== null) {
      setActiveImageIdx(activeImageIdx === 0 ? images.length - 1 : activeImageIdx - 1);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeImageIdx !== null) {
      setActiveImageIdx(activeImageIdx === images.length - 1 ? 0 : activeImageIdx + 1);
    }
  };

  const currentImg = activeImageIdx !== null ? images[activeImageIdx] : null;

  return (
    <section
      id="gallery"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Visual Tour
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Our Facilities Showcase
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold mb-2 ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Inspect our customized training turf visually before visiting. Each machine is selected carefully, clean, and calibrated to maximum performance benchmarks weekly.
          </p>
          <div className="inline-flex items-center gap-1.5 text-xs text-lime-450 font-bold uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            Click on any card to slide through complete detail view
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="gallery-grid-matrix">
          {images.map((img, idx) => (
            <motion.div
              key={img.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              onClick={() => setActiveImageIdx(idx)}
              className={`group relative rounded-2xl overflow-hidden border cursor-crosshair backdrop-blur-xl ${
                dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
              }`}
            >
              {/* Photo */}
              <div className="aspect-[4/3] overflow-hidden w-full relative">
                <img
                  referrerPolicy="no-referrer"
                  src={img.url}
                  alt={img.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                
                {/* Micro zoom overlay */}
                <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg ${
                    dark ? "bg-lime-500 text-black shadow-lime-500/10" : "bg-lime-600 text-white shadow-lime-600/10"
                  }`}>
                    <ZoomIn className="w-5.5 h-5.5" />
                  </div>
                </div>

                {/* Left Category Badge */}
                <span className={`absolute top-3 left-3 border px-2.5 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                  dark ? "bg-black/60 border-white/5 text-lime-400" : "bg-white/60 border-black/5 text-lime-650"
                }`}>
                  {img.category}
                </span>
              </div>

              {/* Descriptions */}
              <div className="p-5 text-left">
                <h3 className={`font-sans text-base font-black uppercase tracking-tight ${dark ? "text-white" : "text-zinc-900"}`}>
                  {img.title}
                </h3>
                <p className={`text-[11px] font-semibold leading-relaxed mt-1.5 ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
                  {img.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Lightbox Preview Modal Overlay */}
        <AnimatePresence>
          {activeImageIdx !== null && currentImg && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6" id="lightbox-zoom-portal">
              {/* Dark Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setActiveImageIdx(null)}
                className="absolute inset-0 bg-black/95 backdrop-blur-md"
              />

              {/* Close Button top corner */}
              <button
                onClick={() => setActiveImageIdx(null)}
                className="absolute top-5 right-5 p-3 rounded-xl bg-white/5 hover:bg-white/10 text-white hover:scale-105 transition-all z-20"
                aria-label="Close Lightbox"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Lightbox Body Container */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: "spring", damping: 28 }}
                className="relative max-w-4xl w-full z-10 flex flex-col items-center"
              >
                {/* Photo Display segment */}
                <div className="relative aspect-[4/3] max-h-[60vh] w-full rounded-2xl overflow-hidden border border-white/10 bg-zinc-950 group">
                  <img
                    referrerPolicy="no-referrer"
                    src={currentImg.url}
                    alt={currentImg.title}
                    className="w-full h-full object-contain"
                  />

                  {/* Left arrow trigger */}
                  <button
                    onClick={handlePrev}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/60 hover:bg-lime-500 hover:text-black transition-colors z-20 shadow-md pointer-events-auto"
                    aria-label="Previous view"
                  >
                    <ChevronLeft className="w-5.5 h-5.5" />
                  </button>

                  {/* Right arrow trigger */}
                  <button
                    onClick={handleNext}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/60 hover:bg-lime-500 hover:text-black transition-colors z-20 shadow-md pointer-events-auto"
                    aria-label="Next view"
                  >
                    <ChevronRight className="w-5.5 h-5.5" />
                  </button>
                </div>

                {/* Sub annotations details card */}
                <div className="w-full mt-4 p-5 rounded-2xl bg-black/80 backdrop-blur-md border border-white/10 text-left text-white max-w-2xl shadow-xl">
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-[10px] font-black uppercase tracking-widest text-lime-400 font-sans">
                      {currentImg.category} • {activeImageIdx + 1} / {images.length}
                    </span>
                  </div>
                  <h3 className="font-sans text-lg font-black uppercase tracking-wide mt-1 leading-tight text-white">
                    {currentImg.title}
                  </h3>
                  <p className="text-zinc-300 text-xs sm:text-sm font-semibold mt-2 leading-relaxed">
                    {currentImg.desc}
                  </p>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
