import React, { useState } from "react";
import { Mail, ArrowRight, Instagram, Facebook, Youtube, Shield, FileText } from "lucide-react";

interface FooterProps {
  dark: boolean;
  onSuccessToast: (msg: string) => void;
}

export default function Footer({ dark, onSuccessToast }: FooterProps) {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitting(true);
    setTimeout(() => {
      onSuccessToast(`Newsletter success! welcome email dispatch initiated for '${email}'. Check inbox shortly!`);
      setEmail("");
      setSubmitting(false);
    }, 1000);
  };

  const menuLinks = [
    { label: "Home Base", href: "home" },
    { label: "About Fitbox", href: "about" },
    { label: "Specialist Services", href: "services" },
    { label: "Pricing Membership", href: "membership" },
    { label: "Elite Teachers", href: "trainers" },
    { label: "Splits Workout", href: "plans" },
    { label: "Photo Gallery", href: "gallery" },
    { label: "Scientific Journal", href: "blog" },
    { label: "FAQ Support", href: "faq" },
    { label: "Contact Details", href: "contact" },
  ];

  const handleFooterLinkClick = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <footer
      id="footer-section"
      className={`pt-16 pb-8 border-t transition-colors duration-500 relative z-10 ${
        dark ? "bg-black/40 border-white/5 backdrop-blur-md" : "bg-white/40 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Newsletter Header Banner section */}
        <div className={`p-8 sm:p-10 rounded-3xl border mb-16 flex flex-col lg:flex-row items-center justify-between gap-8 text-left backdrop-blur-xl ${
          dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10"
        }`} id="footer-newsletter-banner">
          <div className="max-w-xl">
            <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
              Weekly Bulletins
            </span>
            <h3 className={`font-sans text-xl sm:text-2xl font-black uppercase mt-1 tracking-tight leading-snug ${
              dark ? "text-white" : "text-zinc-900"
            }`}>
              Join Our Athlete Circle
            </h3>
            <p className={`text-xs sm:text-sm font-semibold leading-relaxed mt-2 ${
              dark ? "text-zinc-400" : "text-zinc-650"
            }`}>
              Subscribe to standard newsletters to receive Coach Vikram's weekly strength logs, macro-recipes, corrected posture sheets, and priority entrance code alerts.
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="w-full max-w-sm flex shrink-0" id="newsletter-inputs">
            <div className={`flex items-center w-full px-4 py-3 rounded-xl border focus-within:ring-2 focus-within:ring-lime-500 focus-within:ring-offset-2 ${
              dark ? "bg-black/30 border-white/10" : "bg-white/60 border-black/10"
            }`}>
              <Mail className="w-4.5 h-4.5 text-zinc-500 mr-2.5" />
              <input
                type="email"
                required
                placeholder="Enter email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-transparent w-full border-none outline-none text-xs sm:text-sm font-semibold text-zinc-300 placeholder-zinc-500 leading-none"
                aria-label="Email for newsletter subscription"
              />
              <button
                type="submit"
                disabled={submitting}
                className="p-1.5 rounded-lg bg-lime-500 hover:bg-lime-600 text-black transition pointer-events-auto"
                aria-label="Submit newsletter email"
              >
                <ArrowRight className="w-4.5 h-4.5" />
              </button>
            </div>
          </form>
        </div>

        {/* Medium Directory columns */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 text-left mb-16" id="footer-directory-grid">
          {/* Col 1: Brand details */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2" id="footer-brand">
              <div className="w-9 h-9 rounded-lg bg-lime-500 flex items-center justify-center text-black font-extrabold text-lg shadow-md shadow-lime-500/10">
                F
              </div>
              <span className="font-sans text-lg font-black uppercase text-zinc-900 dark:text-white">
                Fit<span className="text-lime-500">Box</span>
              </span>
            </div>
            
            <p className={`text-xs leading-relaxed font-semibold ${dark ? "text-zinc-400" : "text-zinc-655"}`}>
              Premier fitness arena situated in Kadugondanahalli, Bengaluru. We specialize in tailored macro budgeting, power lifts, high-intensity circuit training templates, and certified physical coaching.
            </p>

            {/* Social profiles */}
            <div className="flex gap-2" id="footer-social-links">
              <a
                href="#footer-section"
                className="p-2 border border-zinc-850 hover:bg-lime-550/10 hover:text-lime-400 rounded-lg text-zinc-400 transition"
                aria-label="Facebook Profile"
              >
                <Facebook className="w-4.5 h-4.5" />
              </a>
              <a
                href="#footer-section"
                className="p-2 border border-zinc-850 hover:bg-lime-550/10 hover:text-lime-400 rounded-lg text-zinc-400 transition"
                aria-label="Instagram Profile"
              >
                <Instagram className="w-4.5 h-4.5" />
              </a>
              <a
                href="#footer-section"
                className="p-2 border border-zinc-850 hover:bg-lime-550/10 hover:text-lime-400 rounded-lg text-zinc-400 transition"
                aria-label="Youtube Channel"
              >
                <Youtube className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links Directory Map */}
          <div className="md:col-span-5 space-y-4">
            <h4 className="font-sans text-xs font-black uppercase tracking-widest text-lime-400">
              Quick Navigation Map
            </h4>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 text-xs font-semibold" id="footer-links-grid">
              {menuLinks.map((item) => (
                <button
                  key={item.href}
                  onClick={() => handleFooterLinkClick(item.href)}
                  className={`text-left text-zinc-550 hover:text-lime-400 transition pointer-events-auto flex items-center gap-1.5`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-lime-500/50" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Col 3: Quick contacts address */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-sans text-xs font-black uppercase tracking-widest text-lime-400">
              Registered Location
            </h4>
            <p className={`text-xs leading-relaxed font-semibold ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
              3rd H Main Rd, opposite Krishna Leela Grand Hotel, St Thomas Town, Kadugondanahalli, Bengaluru, Karnataka 560084
            </p>
            <div className="space-y-1 text-xs font-semibold text-zinc-550" id="footer-quick-contacts">
              <p>Hotline: <span className="text-lime-500 dark:text-lime-400 underline">092076 64477</span></p>
              <p>Email: <span className="text-zinc-400">admin@fitboxgym.in</span></p>
            </div>
          </div>
        </div>

        {/* Bottom Metadata copyright row */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-8 border-t border-zinc-200/50 dark:border-zinc-900 text-[10px] font-semibold uppercase tracking-widest text-zinc-500" id="footer-bottom-row">
          <p>© 2026 FitBox Gym Bengaluru. All Physical Rights Reserved.</p>
          
          <div className="flex gap-4" id="footer-privacy-links">
            <a href="#footer-section" className="hover:text-amber-500 transition flex items-center gap-1">
              <Shield className="w-3.5 h-3.5" />
              <span>Safety Rules</span>
            </a>
            <a href="#footer-section" className="hover:text-amber-500 transition flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" />
              <span>Terms of Use</span>
            </a>
          </div>
        </div>
        
      </div>
    </footer>
  );
}
