import { Target, Compass, ShieldCheck, HeartPulse, Clock, Sparkle } from "lucide-react";
import { motion } from "motion/react";

interface AboutProps {
  dark: boolean;
}

export default function About({ dark }: AboutProps) {
  const values = [
    {
      title: "Our Mission",
      desc: "To democratize elite level training, nutritional blueprints, and professional coaching. We empower individuals to correct bad postures, eliminate junk physical habits, and cultivate long-term organic stamina.",
      icon: Target,
      color: "bg-lime-500/15 border-lime-500/20 text-lime-400",
    },
    {
      title: "Our Vision",
      desc: "To establish FitBox Gym as the absolute standard of physical culture in Bengaluru, recognized for science-backed coaching checklists, clean supportive communities, and uncompromised structural premium design.",
      icon: Compass,
      color: "bg-emerald-500/15 border-emerald-500/20 text-emerald-400",
    },
  ];

  const highlights = [
    {
      title: "15,000+ Sq Ft Modern Turf",
      desc: "Optimally designed structural zones segregating strength plate-loaded gear, dumbbell grids, cardio loops, and HIIT circuits.",
      icon: Sparkle,
    },
    {
      title: "Fully Certified K11 & ACE Coaches",
      desc: "Zero guess routines. Every coach is fully certified with a deep grasp of structural biomechanics, anatomy, and dietary sports science.",
      icon: ShieldCheck,
    },
    {
      title: "Pristine Sanitized Hygiene",
      desc: "Dedicated internal hygiene sweeps every 2 hours, fully pressurized hot water shower systems, and sanitized gear standards.",
      icon: HeartPulse,
    },
    {
      title: "Extended 5:00 AM - 10:00 PM Timings",
      desc: "Fit your workout exactly when you want. No more rushed sets due to office hours or early mornings.",
      icon: Clock,
    },
  ];

  return (
    <section
      id="about"
      className={`py-24 transition-colors duration-500 border-t relative z-10 ${
        dark ? "bg-black/40 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Block */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Discover Fitbox Club
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-2 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            We Build Athletes, <br />Not Just Competitors
          </h2>
          <p className={`text-sm sm:text-base mt-4 leading-relaxed font-medium ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            FitBox Gym is the premier fitness sanctuary of Kadugondanahalli, Bengaluru. We serve a clean, highly energetic training workspace designed explicitly for active professionals, powerlifters, athletic students, and those seeking permanent physical health transformations.
          </p>
        </div>

        {/* Mission & Vision Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {values.map((v, idx) => {
            const Icon = v.icon;
            return (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, x: idx % 2 === 0 ? -40 : 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className={`p-8 rounded-2xl border shadow-sm backdrop-blur-xl ${
                  dark
                    ? "bg-white/5 border-white/10 text-zinc-100"
                    : "bg-black/5 border-black/10 text-zinc-900"
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 border ${v.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-sans text-xl font-bold uppercase tracking-wide mb-3">
                  {v.title}
                </h3>
                <p className={`text-sm leading-relaxed ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
                  {v.desc}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Why Choose Fitbox section */}
        <div className="mt-16">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className={`font-sans text-2xl sm:text-3xl font-black uppercase tracking-tight ${
              dark ? "text-white" : "text-zinc-900"
            }`}>
              Why Choose FitBox Gym?
            </h3>
            <p className={`text-xs sm:text-sm mt-2 ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
              Unlock premium standards, supportive communities, and uncompromised facilities built around active goals.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={`p-6 rounded-2xl transition-all duration-300 border hover:-translate-y-1 ${
                    dark
                      ? "bg-white/5 border-white/10 hover:border-lime-500/35 text-white shadow-md hover:bg-white/10"
                      : "bg-black/5 border-black/10 hover:border-lime-650/35 text-zinc-900 shadow hover:shadow-md"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-4 border ${
                    dark 
                      ? "bg-lime-500/10 border-lime-500/20 text-lime-400" 
                      : "bg-lime-500/10 border-lime-600/20 text-lime-600"
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h4 className="font-sans text-base font-black uppercase tracking-tight mb-2">
                    {item.title}
                  </h4>
                  <p className={`text-xs leading-relaxed font-semibold ${
                    dark ? "text-zinc-400" : "text-zinc-600"
                  }`}>
                    {item.desc}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
