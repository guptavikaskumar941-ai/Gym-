import { useState, useEffect } from "react";
import { Scale, Heart, AlertCircle, Apple, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface BMICalculatorProps {
  dark: boolean;
}

export default function BMICalculator({ dark }: BMICalculatorProps) {
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  
  // Metric States
  const [weightKg, setWeightKg] = useState<number>(70);
  const [heightCm, setHeightCm] = useState<number>(172);

  // Imperial States
  const [weightLbs, setWeightLbs] = useState<number>(154);
  const [heightFt, setHeightFt] = useState<number>(5);
  const [heightIn, setHeightIn] = useState<number>(8);

  const [bmi, setBmi] = useState<number>(23.66);
  const [category, setCategory] = useState<string>("Normal Weight");
  const [colorClass, setColorClass] = useState<string>("text-green-500 bg-green-500/10 border-green-500/20");

  useEffect(() => {
    let calculatedBmi = 0;
    if (unit === "metric") {
      calculatedBmi = weightKg / Math.pow(heightCm / 100, 2);
    } else {
      const totalInches = heightFt * 12 + heightIn;
      calculatedBmi = (weightLbs * 703) / Math.pow(totalInches, 2);
    }

    if (isNaN(calculatedBmi) || !isFinite(calculatedBmi) || calculatedBmi < 5) {
      setBmi(0);
      setCategory("Enter valid measurements");
      setColorClass("text-zinc-500 bg-zinc-550/15 border-zinc-500/10");
      return;
    }

    const value = Math.round(calculatedBmi * 100) / 100;
    setBmi(value);

    // Determine category
    if (value < 18.5) {
      setCategory("Underweight");
      setColorClass("text-sky-500 bg-sky-500/10 border-sky-500/20");
    } else if (value >= 18.5 && value < 25) {
      setCategory("Normal Weight");
      setColorClass("text-green-500 bg-green-500/10 border-green-500/20");
    } else if (value >= 25 && value < 30) {
      setCategory("Overweight");
      setColorClass("text-amber-500 bg-amber-500/10 border-amber-500/20");
    } else {
      setCategory("Obese");
      setColorClass("text-red-500 bg-red-500/10 border-red-500/20");
    }
  }, [unit, weightKg, heightCm, weightLbs, heightFt, heightIn]);

  // Diet and physical guidelines based on category
  const getRecommendations = () => {
    switch (category) {
      case "Underweight":
        return {
          targets: "Caloric Surplus (+350 to +500 kcal daily)",
          diet: "Integrate dense local foods like ragi mudde, raw peanut butter, nuts, local ghee (spoonful on meals), whole eggs, and thick sattu milkshakes.",
          training: "Focus on compound lifting routines (Squats, Rows, Bench) 3 times a week with progressive loads. Keep cardio actions to a low warm-up.",
        };
      case "Normal Weight":
        return {
          targets: "Body Recomposition & Lean Hypertrophy",
          diet: "Balance macro nutrients cleanly. Focus on 1.6g of clean protein per kg of bodyweight. Paneer, cooked soya chunks, pulses, and lean chicken breast.",
          training: "Stick to intermediate Push-Pull-Legs schedules with heavy strength benchmarks. Introduce active recovery runs or swimming on off-days.",
        };
      case "Overweight":
        return {
          targets: "Caloric Deficit (-300 to -500 kcal daily)",
          diet: "Cut refined sugars and oil calories. Consume high volume raw salads, roasted gram flour (sattu), steamed lentils, and high grain ragi.",
          training: "Increase metabolic conditioning. Add 2 HIIT circuit sessions per week to standard strength lifting. Target 10,000 steps daily.",
        };
      case "Obese":
        return {
          targets: "Controlled Weight Management & Cardio",
          diet: "Consult Coach Priya for a medical macro chart. Prioritize low glycemic carbs, clear vegetable soups, and clean protein portions.",
          training: "Start with low-impact cardio (stationary air cycle, incline walking) to protect knee joints. Pair with light dumbbell hypertrophy repetitions.",
        };
      default:
        return {
          targets: "Join Fitbox Bengaluru for expert guidelines",
          diet: "Check our customized meal plans by selecting our Quarter or Annual Elite memberships details.",
          training: "We formulate tailored workout schedules upon sign-up.",
        };
    }
  };

  const advice = getRecommendations();

  return (
    <section
      id="bmi-section"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Metabolic Engine
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            BMI Biometric Calculator
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Calculate your Body Mass Index (BMI) dynamically in real-time. Review your active wellness score and receive tailored nutrient guidelines from Coach Sarah instantly!
          </p>
        </div>

        {/* Double Columns Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch" id="bmi-widget-flexbox">
          {/* Column Left: Input Controllers */}
          <div className={`p-6 sm:p-8 rounded-3xl border lg:col-span-7 text-left flex flex-col justify-between backdrop-blur-xl ${
            dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
          }`}>
            <div>
              {/* Unit Toggler tabs */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <Scale className="w-5 h-5 text-lime-400" />
                  <span className={`text-sm font-black uppercase tracking-wider ${dark ? "text-white" : "text-zinc-800"}`}>
                    System unit
                  </span>
                </div>
                <div className="flex bg-zinc-800/10 p-1 rounded-xl border border-zinc-200/40 dark:border-white/5">
                  <button
                    onClick={() => setUnit("metric")}
                    className={`px-4 py-1.5 rounded-lg text-xs font-black uppercase transition-all ${
                      unit === "metric" ? "bg-lime-500 text-black shadow-sm" : "text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300"
                    }`}
                  >
                    Metric (cm/kg)
                  </button>
                  <button
                    onClick={() => setUnit("imperial")}
                    className={`px-4 py-1.5 rounded-lg text-xs font-black uppercase transition-all ${
                      unit === "imperial" ? "bg-lime-500 text-black shadow-sm" : "text-zinc-500 hover:text-zinc-850 dark:hover:text-zinc-300"
                    }`}
                  >
                    Imperial (ft/lbs)
                  </button>
                </div>
              </div>

              {/* Metric Sliders */}
              {unit === "metric" ? (
                <div className="space-y-6">
                  {/* Height Metric */}
                  <div>
                    <div className="flex justify-between items-baseline mb-2">
                      <span className={`text-xs font-black uppercase tracking-wider ${dark ? "text-zinc-300" : "text-zinc-700"}`}>
                        Your Height
                      </span>
                      <span className={`font-mono text-xl font-extrabold ${dark ? "text-lime-400" : "text-lime-650"}`}>
                        {heightCm} <span className="text-xs text-zinc-500 uppercase">cm</span>
                      </span>
                    </div>
                    <input
                      type="range"
                      min="120"
                      max="220"
                      step="1"
                      value={heightCm}
                      onChange={(e) => setHeightCm(parseInt(e.target.value))}
                      className={`w-full cursor-pointer h-2 rounded-lg bg-zinc-200 dark:bg-zinc-800 ${dark ? "accent-lime-400" : "accent-lime-600"}`}
                      aria-label="Height in centimeters"
                    />
                    <div className="flex justify-between text-[10px] text-zinc-500 font-bold uppercase mt-1">
                      <span>120 cm</span>
                      <span>170 cm</span>
                      <span>220 cm</span>
                    </div>
                  </div>

                  {/* Weight Metric */}
                  <div>
                    <div className="flex justify-between items-baseline mb-2">
                      <span className={`text-xs font-black uppercase tracking-wider ${dark ? "text-zinc-300" : "text-zinc-700"}`}>
                        Your Weight
                      </span>
                      <span className={`font-mono text-xl font-extrabold ${dark ? "text-lime-400" : "text-lime-650"}`}>
                        {weightKg} <span className="text-xs text-zinc-500 uppercase">kg</span>
                      </span>
                    </div>
                    <input
                      type="range"
                      min="35"
                      max="150"
                      step="1"
                      value={weightKg}
                      onChange={(e) => setWeightKg(parseInt(e.target.value))}
                      className={`w-full cursor-pointer h-2 rounded-lg bg-zinc-200 dark:bg-zinc-800 ${dark ? "accent-lime-400" : "accent-lime-600"}`}
                      aria-label="Weight in kilograms"
                    />
                    <div className="flex justify-between text-[10px] text-zinc-500 font-bold uppercase mt-1">
                      <span>35 kg</span>
                      <span>92 kg</span>
                      <span>150 kg</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Height Imperial fields */}
                  <div>
                    <span className={`block text-xs font-black uppercase tracking-wider mb-2 text-zinc-400`}>
                      Your Height
                    </span>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex items-center justify-between p-3.5 rounded-xl border border-zinc-300 dark:border-zinc-800 bg-white/5 dark:bg-black/20 backdrop-blur-md">
                          <input
                            type="number"
                            min="3"
                            max="8"
                            value={heightFt}
                            onChange={(e) => setHeightFt(Math.max(1, parseInt(e.target.value) || 0))}
                            className="bg-transparent w-full text-lg font-mono font-bold focus:outline-none"
                            aria-label="Height in feet"
                          />
                          <span className="text-xs uppercase font-extrabold text-zinc-500">Feet</span>
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between p-3.5 rounded-xl border border-zinc-300 dark:border-zinc-800 bg-white/5 dark:bg-black/20 backdrop-blur-md">
                          <input
                            type="number"
                            min="0"
                            max="11"
                            value={heightIn}
                            onChange={(e) => setHeightIn(Math.max(0, parseInt(e.target.value) || 0))}
                            className="bg-transparent w-full text-lg font-mono font-bold focus:outline-none"
                            aria-label="Height in inches"
                          />
                          <span className="text-xs uppercase font-extrabold text-zinc-500">Inches</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Weight Imperial */}
                  <div>
                    <div className="flex justify-between items-baseline mb-2">
                      <span className={`text-xs font-black uppercase tracking-wider ${dark ? "text-zinc-300" : "text-zinc-700"}`}>
                        Your Weight
                      </span>
                      <span className={`font-mono text-xl font-extrabold ${dark ? "text-lime-400" : "text-lime-650"}`}>
                        {weightLbs} <span className="text-xs text-zinc-500 uppercase">lbs</span>
                      </span>
                    </div>
                    <input
                      type="range"
                      min="75"
                      max="330"
                      step="1"
                      value={weightLbs}
                      onChange={(e) => setWeightLbs(parseInt(e.target.value))}
                      className={`w-full cursor-pointer h-2 rounded-lg bg-zinc-200 dark:bg-zinc-800 ${dark ? "accent-lime-400" : "accent-lime-600"}`}
                      aria-label="Weight in pounds"
                    />
                    <div className="flex justify-between text-[10px] text-zinc-500 font-bold uppercase mt-1">
                      <span>75 lbs</span>
                      <span>200 lbs</span>
                      <span>330 lbs</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Chart Guide Legend */}
            <div className="mt-8 border-t border-zinc-250/30 dark:border-zinc-800/60 pt-6">
              <span className={`block text-xs font-black uppercase tracking-wider mb-2.5 ${dark ? "text-zinc-400" : "text-zinc-600"}`}>
                Health Indicator Ranges Reference:
              </span>
              <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-bold uppercase">
                <div className="p-2.5 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-500">
                  <span>&lt; 18.5</span>
                  <p className="font-light mt-0.5">Lean</p>
                </div>
                <div className="p-2.5 rounded-xl bg-green-500/10 border border-green-500/20 text-green-500">
                  <span>18.5 - 24.9</span>
                  <p className="font-light mt-0.5">Healthy</p>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-500">
                  <span>25 - 29.9</span>
                  <p className="font-light mt-0.5">Heavy</p>
                </div>
                <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500">
                  <span>30+</span>
                  <p className="font-light mt-0.5">Obese</p>
                </div>
              </div>
            </div>
          </div>

          {/* Column Right: BMI Gauge dial output & Specific diet guidelines */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Output Card */}
            <div className={`p-6 sm:p-8 rounded-3xl border text-center relative overflow-hidden backdrop-blur-xl ${
              dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
            }`}>
              <span className={`block text-[11px] font-black uppercase tracking-widest ${dark ? "text-zinc-400" : "text-zinc-500"}`}>
                Your Biological Score
              </span>
              
              {/* BMI score numerical display */}
              <div className="my-6">
                <span className={`font-mono text-5xl sm:text-6xl font-black select-all block leading-none ${dark ? "text-lime-400" : "text-lime-650"}`}>
                  {bmi}
                </span>
                
                {/* Visual Category Badge */}
                <div className={`inline-flex px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider mt-4.5 border ${colorClass}`} id="bmi-status-badge">
                  {category}
                </div>
              </div>

              {/* Quick Alert indicator */}
              <div className="flex items-start gap-2.5 p-3.5 rounded-2xl bg-zinc-805/10 dark:bg-white/5 border border-zinc-305/30 dark:border-white/5 text-left text-xs font-semibold leading-relaxed">
                <AlertCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                <p className={dark ? "text-zinc-300" : "text-zinc-650"}>
                  This is a general calculation tool based on structural height. For specialized athletic body composition metrics (including bodyfat percentages), schedule an assessment using our 15,000 sq ft physical center!
                </p>
              </div>
            </div>

            {/* Nutrients & Activity Advise Card */}
            <div className={`p-6 sm:p-8 rounded-3xl border text-left backdrop-blur-xl ${
              dark ? "bg-white/5 border-white/10 text-white" : "bg-black/5 border-black/10 shadow-sm text-zinc-900"
            }`}>
              <div className="flex items-center gap-2 mb-4">
                <Apple className={`w-5 h-5 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                <h3 className="font-sans text-base font-black uppercase tracking-wider">
                  Nutrient Plan Recommendations:
                </h3>
              </div>

              <div className="space-y-4 text-xs font-semibold">
                <div>
                  <span className="text-[10px] block font-black uppercase tracking-widest text-lime-400 leading-none mb-1">
                    TARGET ENERGY LEVEL
                  </span>
                  <p className={dark ? "text-zinc-200" : "text-zinc-800"}>{advice.targets}</p>
                </div>

                <div>
                  <span className="text-[10px] block font-black uppercase tracking-widest text-lime-450 dark:text-lime-400 leading-none mb-1">
                    BENGALURU-OPTIMIZED DIET CHARTS
                  </span>
                  <p className={dark ? "text-zinc-350" : "text-zinc-650"}>{advice.diet}</p>
                </div>

                <div>
                  <span className="text-[10px] block font-black uppercase tracking-widest text-lime-450 dark:text-lime-400 leading-none mb-1">
                    RECOMMENDED PHYSICAL REPS
                  </span>
                  <p className={dark ? "text-zinc-350" : "text-zinc-650"}>{advice.training}</p>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
