import { useEffect } from "react";

export default function SEOMeta() {
  useEffect(() => {
    // Dynamic Meta Tags updates
    document.title = "FitBox Gym Bengaluru | Weight Training, Powerlifting & HIIT Circuits";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "FitBox Gym Kadugondanahalli is Bengaluru's premier powerlifting, strength conditioning, and circuit training gym. ACE/K11 certified coaches, free trials, and customized diet blueprints.");
    } else {
      const meta = document.createElement("meta");
      meta.name = "description";
      meta.content = "FitBox Gym Kadugondanahalli is Bengaluru's premier powerlifting, strength conditioning, and circuit training gym. ACE/K11 certified coaches, free trials, and customized diet blueprints.";
      document.head.appendChild(meta);
    }

    // JSON-LD structured schema script block
    const existingSchema = document.getElementById("fitbox-structured-schema");
    if (!existingSchema) {
      const script = document.createElement("script");
      script.id = "fitbox-structured-schema";
      script.type = "application/ld+json";
      script.innerHTML = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "ExerciseGym",
        "name": "FitBox Gym",
        "image": "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "3rd H Main Rd, opposite Krishna Leela Grand Hotel, St Thomas Town, Kadugondanahalli",
          "addressLocality": "Bengaluru",
          "addressRegion": "Karnataka",
          "postalCode": "560084",
          "addressCountry": "IN"
        },
        "telephone": "+91-92076-64477",
        "url": "https://fitboxgym.in",
        "priceRange": "₹2500 - ₹18000",
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.6",
          "reviewCount": "280"
        },
        "openingHoursSpecification": [
          {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            "opens": "05:00",
            "closes": "22:00"
          },
          {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": "Sunday",
            "opens": "07:00",
            "closes": "14:00"
          }
        ]
      });
      document.head.appendChild(script);
    }
  }, []);

  return null; // Side-effects only
}
