import { useState, useEffect } from "react";
import { Sun, Moon, Menu, X, ArrowUp } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  dark: boolean;
  toggleDark: () => void;
}

export default function Navbar({ currentTab, setCurrentTab, dark, toggleDark }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  const navItems = [
    { id: "home", label: "Home" },
    { id: "about", label: "About" },
    { id: "services", label: "Services" },
    { id: "membership", label: "Membership" },
    { id: "trainers", label: "Trainers" },
    { id: "plans", label: "Programs" },
    { id: "gallery", label: "Gallery" },
    { id: "blog", label: "Blog" },
    { id: "faq", label: "FAQ" },
    { id: "contact", label: "Contact" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      setShowScrollTop(window.scrollY > 400);

      // Simple active tab indicator based on scroll position
      const sections = navItems.map((item) => document.getElementById(item.id));
      const scrollPosition = window.scrollY + 120;

      for (let i = sections.length - 1; i >= 0; i--) {
        const sec = sections[i];
        if (sec && sec.offsetTop <= scrollPosition) {
          setCurrentTab(navItems[i].id);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [setCurrentTab]);

  const handleNavClick = (id: string) => {
    setMobileOpen(false);
    setCurrentTab(id);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
    setCurrentTab("home");
  };

  return (
    <>
      <header
        id="navbar-header"
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
          scrolled
            ? dark
              ? "bg-black/30 border-b border-white/10 shadow-lg backdrop-blur-md"
              : "bg-white/40 border-b border-black/10 shadow-md backdrop-blur-md"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Logo */}
          <div
            onClick={() => handleNavClick("home")}
            className="flex items-center gap-2 cursor-pointer select-none group"
            id="nav-logo-container"
          >
            <div className="w-10 h-10 rounded-xl bg-lime-500 flex items-center justify-center text-black font-extrabold text-xl shadow-lg shadow-lime-500/30 group-hover:scale-105 transition-transform duration-300">
              FB
            </div>
            <span className="font-sans text-xl font-black tracking-wider uppercase flex items-center">
              Fit<span className="text-lime-500 text-transparent bg-clip-text bg-gradient-to-r from-lime-400 to-emerald-400">Box</span>
              <span className="ml-1 text-[10px] font-bold tracking-widest px-1 py-0.5 rounded bg-lime-500/10 text-lime-500 border border-lime-500/20 uppercase hidden sm:inline-block">
                Gym
              </span>
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1.5" id="desktop-nav">
            {navItems.map((item) => {
              const active = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative px-3.5 py-2 rounded-lg text-sm font-semibold tracking-wide transition-all duration-300 pointer-events-auto ${
                    active
                      ? dark
                        ? "text-lime-400"
                        : "text-lime-650 font-bold"
                      : dark
                        ? "text-zinc-300 hover:text-white hover:bg-white/5 hover:backdrop-blur-md"
                        : "text-zinc-650 hover:text-zinc-900 hover:bg-black/5 hover:backdrop-blur-md"
                  }`}
                >
                  {item.label}
                  {active && (
                    <motion.div
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 left-3.5 right-3.5 h-[2.5px] bg-lime-500 rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Actions: Theme Toggle & Join CTA / Mobile Trigger */}
          <div className="flex items-center gap-3" id="nav-actions">
            {/* Theme Toggle */}
            <button
              onClick={toggleDark}
              className={`p-2.5 rounded-xl border transition-all duration-300 ${
                dark
                  ? "bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10 backdrop-blur-md"
                  : "bg-black/5 border-black/10 text-zinc-700 hover:bg-black/10 backdrop-blur-md"
              }`}
              aria-label="Toggle Theme"
              id="theme-toggler"
            >
              {dark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-zinc-600" />}
            </button>

            {/* Quick Inquiry CTA */}
            <button
              onClick={() => handleNavClick("membership")}
              className="hidden sm:inline-flex px-5 py-2.5 rounded-xl text-sm font-bold tracking-wide uppercase bg-lime-500 hover:bg-lime-600 text-black shadow-md shadow-lime-500/25 active:scale-[0.98] transition-all duration-300"
              id="header-cta-button"
            >
              Join Club
            </button>

            {/* Hamburger Button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className={`lg:hidden p-2.5 rounded-xl border transition-all duration-300 ${
                dark
                  ? "bg-white/5 border-white/10 text-zinc-450 hover:text-white backdrop-blur-md"
                  : "bg-black/5 border-black/10 text-zinc-600 hover:text-zinc-900 backdrop-blur-md"
              }`}
              aria-label="Toggle Mobile Menu"
              id="mobile-menu-trigger"
            >
              {mobileOpen ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Side Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-50 lg:hidden" id="mobile-drawer-portal">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Drawer Content */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className={`absolute top-0 right-0 w-4/5 max-w-sm h-full shadow-2xl flex flex-col justify-between ${
                dark ? "bg-zinc-950 border-l border-zinc-900" : "bg-white border-l border-zinc-200"
              }`}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-lg bg-lime-500 flex items-center justify-center text-black font-extrabold text-lg shadow-md">
                      FB
                    </div>
                    <span className="font-sans text-lg font-black uppercase">
                      Fit<span className="text-lime-500">Box</span>
                    </span>
                  </div>
                  <button
                    onClick={() => setMobileOpen(false)}
                    className={`p-2 rounded-lg border ${
                      dark ? "bg-white/5 border-white/10 text-zinc-400" : "bg-zinc-50 border-zinc-200 text-zinc-600"
                    }`}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <nav className="flex flex-col gap-2">
                  {navItems.map((item) => {
                    const active = currentTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-base font-bold tracking-wide transition-all duration-200 ${
                          active
                            ? dark
                              ? "bg-lime-500/10 text-lime-400 border border-lime-500/20"
                              : "bg-lime-50 text-lime-650 border border-lime-200"
                            : dark
                              ? "text-zinc-300 hover:bg-white/5"
                              : "text-zinc-700 hover:bg-zinc-50"
                        }`}
                      >
                        {item.label}
                        {active && <span className="w-2 h-2 rounded-full bg-lime-500" />}
                      </button>
                    );
                  })}
                </nav>
              </div>

              <div className="p-6 border-t border-zinc-800/10 bg-white/5 backdrop-blur-md">
                <button
                  onClick={() => handleNavClick("contact")}
                  className="w-full py-4.5 rounded-xl font-bold tracking-wide uppercase text-center bg-lime-500 hover:bg-lime-600 text-black shadow-xl shadow-lime-500/20 transition-all duration-300"
                >
                  Book Free Trial
                </button>
                <p className="text-center text-[11px] text-zinc-500 font-medium mt-3 tracking-wide">
                  St Thomas Town • Kadugondanahalli • Bengaluru
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Scroll-to-Top Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={handleScrollToTop}
            className="fixed bottom-6 left-6 z-40 p-3.5 rounded-full shadow-2xl bg-lime-500 hover:bg-lime-600 text-black hover:scale-105 active:scale-95 transition-all duration-300"
            aria-label="Scroll to top"
            id="back-to-top-button"
          >
            <ArrowUp className="w-5.5 h-5.5" />
          </motion.button>
        )}
      </AnimatePresence>
    </>
  );
}
