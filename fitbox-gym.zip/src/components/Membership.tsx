import React, { useState } from "react";
import { membershipPlansData } from "../data";
import { MembershipPlan } from "../types";
import { Check, X, ShieldAlert, ShoppingBag, Send } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MembershipProps {
  dark: boolean;
  onSuccessToast: (msg: string) => void;
}

export default function Membership({ dark, onSuccessToast }: MembershipProps) {
  const [selectedPlan, setSelectedPlan] = useState<MembershipPlan | null>(null);
  const [formData, setFormData] = useState({ name: "", phone: "", email: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);

  const openBookingModal = (plan: MembershipPlan) => {
    setSelectedPlan(plan);
  };

  const closeBookingModal = () => {
    setSelectedPlan(null);
    setFormData({ name: "", phone: "", email: "", notes: "" });
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      alert("Name and Phone number are required to register!");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      onSuccessToast(
        `Success! Booking request received for '${selectedPlan?.name}'. Coach Vikram will contact you shortly via call/WhatsApp!`
      );
      closeBookingModal();
    }, 1200);
  };

  return (
    <section
      id="membership"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Tiered Packages
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-2 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Flexible Gym Memberships
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold mb-2 ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Select an elite category tier that synchronizes with your personal budget and body transition targets. No hidden administrative fees, pure premium physical access.
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 text-lime-400 rounded-lg text-xs font-bold uppercase mt-2 backdrop-blur-md">
            <ShieldAlert className="w-3.5 h-3.5" />
            No registration fees on any plan this month!
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {membershipPlansData.map((plan, idx) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`relative rounded-3xl border p-8 flex flex-col justify-between transition-all duration-300 backdrop-blur-xl ${
                plan.highlighted
                  ? dark
                    ? "bg-white/10 border-white/20 shadow-2xl shadow-lime-550/10 md:scale-105 z-10"
                    : "bg-black/5 border-black/20 shadow-2xl shadow-lime-600/10 md:scale-105 z-10"
                  : dark
                    ? "bg-white/5 border-white/10 hover:border-lime-500/35 hover:bg-white/10"
                    : "bg-black/5 border-black/10 hover:border-lime-600/35 hover:bg-black/10"
              }`}
            >
              {/* Highlight Tag */}
              {plan.tag && (
                <div className={`absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest backdrop-blur-lg ${
                  plan.highlighted
                    ? "bg-lime-500 text-black shadow-md shadow-lime-500/20"
                    : dark
                      ? "bg-white/10 text-lime-400 border border-white/10"
                      : "bg-black/10 text-lime-600 border border-black/10"
                }`}>
                  {plan.tag}
                </div>
              )}

              <div>
                {/* Plan Header */}
                <h3 className={`font-sans text-lg font-black uppercase tracking-wide mt-2 ${
                  dark ? "text-white" : "text-zinc-900"
                }`}>
                  {plan.name}
                </h3>

                {/* Pricing Block */}
                <div className="my-6">
                  <div className="flex items-baseline gap-1" id={`price-display-${plan.id}`}>
                    <span className={`font-mono text-4xl sm:text-5xl font-black tracking-tight ${dark ? "text-lime-400 animate-pulse" : "text-lime-650"}`}>
                      ₹{plan.price.toLocaleString("en-IN")}
                    </span>
                    <span className={`text-xs font-bold uppercase tracking-wider ${
                      dark ? "text-zinc-500" : "text-zinc-455"
                    }`}>
                      / {plan.period}
                    </span>
                  </div>
                  {/* Calculation descriptor */}
                  {plan.period === "3 Months" && (
                    <p className="text-[11px] text-zinc-500 font-bold mt-1 uppercase tracking-wide">
                      Equivalent to ₹{(Math.round(plan.price / 3)).toLocaleString("en-IN")}/month
                    </p>
                  )}
                  {plan.period === "6 Months" && (
                    <p className="text-[11px] text-zinc-500 font-bold mt-1 uppercase tracking-wide">
                      Equivalent to ₹{(Math.round(plan.price / 6)).toLocaleString("en-IN")}/month
                    </p>
                  )}
                  {plan.period === "Year" && (
                    <p className="text-[11px] text-zinc-500 font-bold mt-1 uppercase tracking-wide">
                      Equivalent to ₹{(Math.round(plan.price / 12)).toLocaleString("en-IN")}/month
                    </p>
                  )}
                </div>

                {/* Features list */}
                <ul className="space-y-3.5 mb-8 text-left border-t border-zinc-805/10 dark:border-white/5 pt-6">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2.5 text-xs sm:text-sm font-semibold">
                      <Check className="w-4 h-4 text-lime-500 flex-shrink-0 mt-0.5" />
                      <span className={dark ? "text-zinc-300" : "text-zinc-650"}>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <button
                onClick={() => openBookingModal(plan)}
                className={`w-full py-3.5 rounded-2xl font-black uppercase text-xs sm:text-sm tracking-widest active:scale-[0.98] transition-all duration-300 pointer-events-auto ${
                  plan.highlighted
                    ? "bg-lime-500 hover:bg-lime-600 text-black shadow-lg shadow-lime-500/20"
                    : dark
                      ? "bg-white/10 hover:bg-white/15 text-white border border-white/10"
                      : "bg-black/10 hover:bg-black/15 text-zinc-800 border border-black/15"
                }`}
              >
                Join Now
              </button>
            </motion.div>
          ))}
        </div>

        {/* Dynamic Join Modal Popup */}
        <AnimatePresence>
          {selectedPlan && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="join-modal-container">
              {/* Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={closeBookingModal}
                className="absolute inset-0 bg-black/75 backdrop-blur-sm"
              />

              {/* Box frame */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -20 }}
                transition={{ type: "spring", damping: 25 }}
                className={`relative w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl z-10 border text-left flex flex-col justify-between backdrop-blur-2xl ${
                  dark ? "bg-zinc-950/90 border-white/10 text-white" : "bg-white/90 border-black/10 text-zinc-900"
                }`}
              >
                {/* Close Button */}
                <button
                  onClick={closeBookingModal}
                  className={`absolute top-4 right-4 p-2 rounded-xl transition-colors ${
                    dark ? "hover:bg-white/5 text-zinc-400 hover:text-white" : "hover:bg-black/5 text-zinc-500"
                  }`}
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Title */}
                <div className="flex items-center gap-3.5 mb-6">
                  <div className="w-11 h-11 bg-lime-500/10 text-lime-400 rounded-xl flex items-center justify-center">
                    <ShoppingBag className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-lime-450 dark:text-lime-400">
                      You are subscribing for:
                    </span>
                    <h3 className="font-sans text-xl font-bold uppercase tracking-wide leading-tight">
                      {selectedPlan.name}
                    </h3>
                  </div>
                </div>

                <p className={`text-xs mb-6 font-semibold ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
                  Enter your contact details below. Our Head Strength Coach will review your biometric goals and contact you directly to process onboarding and assign entry tokens.
                </p>

                {/* Form */}
                <form onSubmit={handleBookingSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-400">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Pranav Gowda"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                        dark
                          ? "bg-white/5 border-white/10 text-white placeholder-zinc-500"
                          : "bg-black/5 border-black/10 text-zinc-900 placeholder-zinc-400"
                      }`}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-400">
                        Phone / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 092076 64477"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                          dark
                            ? "bg-white/5 border-white/10 text-white placeholder-zinc-500"
                            : "bg-black/5 border-black/10 text-zinc-900 placeholder-zinc-400"
                        }`}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-400">
                        Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. name@domain.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                          dark
                            ? "bg-white/5 border-white/10 text-white placeholder-zinc-500"
                            : "bg-black/5 border-black/10 text-zinc-900 placeholder-zinc-400"
                        }`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-400">
                      Message / Fitness Objectives
                    </label>
                    <textarea
                      rows={2}
                      placeholder="e.g. Looking to gain 5kg of muscle, correct squat posture, and macro schedule."
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 resize-none ${
                        dark
                          ? "bg-white/5 border-white/10 text-white placeholder-zinc-500"
                          : "bg-black/5 border-black/10 text-zinc-900 placeholder-zinc-400"
                      }`}
                    />
                  </div>

                  {/* Submit buttons */}
                  <div className="flex gap-3 mt-6">
                    <button
                      type="button"
                      onClick={closeBookingModal}
                      className={`flex-1 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider text-center border ${
                        dark ? "border-white/10 hover:bg-white/5" : "border-black/10 hover:bg-black/5"
                      }`}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-[2] py-3.5 rounded-xl text-xs font-black uppercase tracking-wider text-center bg-lime-500 text-black hover:bg-lime-600 flex items-center justify-center gap-2 shadow-lg shadow-lime-500/20"
                    >
                      {submitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          Scheduling...
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          Confirm & Book
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
