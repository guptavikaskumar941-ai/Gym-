import { Star, Award, Trophy, MapPin, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface HeroProps {
  dark: boolean;
  onJoinClick: () => void;
  onTrialClick: () => void;
  onContactClick: () => void;
}

export default function Hero({ dark, onJoinClick, onTrialClick, onContactClick }: HeroProps) {
  const stats = [
    { value: "4.6 ★", label: "280+ Reviews", desc: "Top-Rated Bengaluru Club", icon: Star, color: "text-amber-400" },
    { value: "12+", label: "Master Trainers", desc: "K11 & ACE Certified Co", icon: Award, color: "text-lime-400" },
    { value: "15,000+", label: "Sq. Ft. Turf", desc: "Top Specialized Machinery", icon: Trophy, color: "text-emerald-400" },
  ];

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-12 overflow-hidden"
    >
      {/* Background Image with Dark Gradient Overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=2000&auto=format&fit=crop"
          alt="FitBox Gym Premium Training Turf"
          className="w-full h-full object-cover scale-105 motion-safe:animate-[pulse_10s_infinite]"
        />
        <div
          className={`absolute inset-0 z-10 transition-colors duration-500 ${
            dark
              ? "bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-zinc-950/80"
              : "bg-gradient-to-t from-white via-zinc-950/60 to-zinc-950/70"
          }`}
        />
      </div>

      {/* Decorative Glow Elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-lime-500/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />

      {/* Hero Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        {/* Short top-tag */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-lime-400 text-xs font-semibold uppercase tracking-[0.2em] mb-6 shadow-sm backdrop-blur-md"
        >
          <Sparkles className="w-3.5 h-3.5 text-lime-400" />
          Certified Premium Gym Bengaluru
        </motion.div>

        {/* Strong headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="max-w-4xl text-4xl sm:text-6xl lg:text-7xl font-sans font-black text-white tracking-tight uppercase leading-[1.05] drop-shadow-md"
        >
          Transform Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-lime-400 to-emerald-400 relative inline-block font-black">Body</span>, <br className="hidden sm:inline" />
          Transform Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-lime-400 to-emerald-400 relative inline-block font-black">Life</span>
        </motion.h1>

        {/* Professional Sub-heading */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="max-w-2xl text-base sm:text-xl text-zinc-150 mt-6 leading-relaxed font-semibold drop-shadow"
        >
          Elevate your physical limits at <span className="text-lime-400 font-black">FitBox Gym</span>, Kadugondanahalli. Fully loaded with premium resistance machinery, specialized fat loss coaching, and custom nutrition charting.
        </motion.p>

        {/* Location alert */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="flex items-center gap-1.5 text-zinc-300 text-xs sm:text-sm font-semibold mt-3 tracking-wide"
        >
          <MapPin className="w-4 h-4 text-lime-400 flex-shrink-0" />
          <span>opposite Krishna Leela Grand Hotel, Kadugondanahalli</span>
        </motion.div>

        {/* CTA Button Block */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10 w-full max-w-md sm:max-w-none px-4"
        >
          {/* Join Now */}
          <button
            onClick={onJoinClick}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-black uppercase tracking-wider bg-lime-500 hover:bg-lime-600 text-black shadow-xl shadow-lime-500/30 active:scale-98 hover:shadow-lime-500/40 transition-all duration-300"
          >
            Join Now
          </button>

          {/* Book Free Trial */}
          <button
            onClick={onTrialClick}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-black uppercase tracking-wider bg-white/5 border border-white/10 text-white backdrop-blur-md hover:bg-white/10 shadow-lg active:scale-98 transition-all duration-300"
          >
            Book Free Trial
          </button>

          {/* Contact Us */}
          <button
            onClick={onContactClick}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-black uppercase tracking-wider bg-transparent hover:bg-white/5 text-white border-2 border-white/20 hover:border-white transition-all duration-300"
          >
            Contact Us
          </button>
        </motion.div>

        {/* Stats segment */}
        <div className="w-full max-w-5xl mt-16" id="stats-section">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat, idx) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.7 + idx * 0.1 }}
                  className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex items-center gap-4 text-left shadow-lg hover:border-lime-500/30 hover:shadow-lime-500/5 transition-all duration-300"
                >
                  <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                    <Icon className={`w-8 h-8 ${stat.color}`} />
                  </div>
                  <div>
                    <h3 className="font-mono text-2xl sm:text-3xl font-black text-white leading-none">
                      {stat.value}
                    </h3>
                    <p className="text-zinc-200 text-sm font-bold mt-1">
                      {stat.label}
                    </p>
                    <p className="text-zinc-400 text-xs mt-0.5 font-medium">
                      {stat.desc}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
