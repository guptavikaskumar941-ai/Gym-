import { useState } from "react";
import { testimonialsData } from "../data";
import { Star, ChevronLeft, ChevronRight, Quote, MessageSquare, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface TestimonialsProps {
  dark: boolean;
}

export default function Testimonials({ dark }: TestimonialsProps) {
  const [slideIdx, setSlideIdx] = useState(0);

  const handlePrev = () => {
    setSlideIdx(slideIdx === 0 ? testimonialsData.length - 1 : slideIdx - 1);
  };

  const handleNext = () => {
    setSlideIdx(slideIdx === testimonialsData.length - 1 ? 0 : slideIdx + 1);
  };

  const activeReview = testimonialsData[slideIdx];

  return (
    <section
      id="testimonials"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Dual Grid block: Left has Rating metrics, Right has interactive carousel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center" id="testimonials-main-frame">
          {/* Column Left: Visual google rating indicator */}
          <div className="lg:col-span-5 text-left space-y-6">
            <div>
              <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
                Member Voices
              </span>
              <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
                dark ? "text-white" : "text-zinc-900"
              }`}>
                What Our Clients Say
              </h2>
            </div>

            <p className={`text-xs sm:text-sm leading-relaxed font-semibold ${
              dark ? "text-zinc-400" : "text-zinc-650"
            }`}>
              With an average rating of <span className="text-lime-500 dark:text-lime-400 font-bold">4.6 out of 5 stars</span> across more than <span className="text-lime-500 dark:text-lime-400 font-extrabold">280+ total verified Google reviews</span>, FitBox Gym is the premier fitness community in Kadugondanahalli, Bengaluru.
            </p>

            {/* Google Rating metric block banner */}
            <div className={`p-6 rounded-2xl border backdrop-blur-md ${
              dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
            }`}>
              <div className="flex items-center gap-2 mb-2">
                <span className={`text-4xl font-mono font-black ${dark ? "text-lime-400" : "text-lime-650"}`}>4.6</span>
                <div>
                  <div className="flex gap-0.5 text-amber-400">
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                  <p className={`text-[10px] font-black uppercase mt-0.5 ${dark ? "text-zinc-400" : "text-zinc-500"}`}>
                    Verified Google Business Score
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-zinc-500 font-bold tracking-wide uppercase">
                Based on 280+ Submissions opposite Leela Grand Hotel
              </p>
            </div>
          </div>

          {/* Column Right: Interactive carousel wrapper */}
          <div className="lg:col-span-7">
            <div className={`relative p-8 sm:p-10 rounded-3xl border text-left backdrop-blur-xl ${
              dark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10 shadow-sm"
            }`} id="testimonial-carousel-box">
              {/* Quote marks */}
              <Quote className="absolute top-6 right-6 w-12 h-12 text-lime-400/10 pointer-events-none" />

              {/* Review card presentation */}
              <div className="min-h-[180px] flex flex-col justify-between">
                <div>
                  {/* Rating Stars */}
                  <div className="flex gap-1 text-amber-400 mb-4" id={`rev-stars-box-${activeReview.id}`}>
                    {Array.from({ length: activeReview.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>

                  {/* Comment */}
                  <p className={`text-sm sm:text-base italic leading-relaxed font-semibold ${
                    dark ? "text-zinc-200" : "text-zinc-750"
                  }`}>
                    "{activeReview.comment}"
                  </p>
                </div>

                {/* Account detail line */}
                <div className="flex items-center justify-between gap-4 mt-6 border-t border-zinc-200/50 dark:border-zinc-850/60 pt-4">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center font-black uppercase text-sm border ${
                      dark ? "bg-lime-500/15 text-lime-400 border-lime-400/20" : "bg-lime-600/10 text-lime-600 border-lime-600/20"
                    }`}>
                      {activeReview.name[0]}
                    </div>
                    <div>
                      <h4 className={`font-sans text-sm font-black uppercase leading-none ${dark ? "text-white" : "text-zinc-900"}`}>
                        {activeReview.name}
                      </h4>
                      <p className="text-[10px] text-zinc-500 font-bold mt-1 uppercase tracking-wider flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                        <span>Verified Member</span>
                      </p>
                    </div>
                  </div>

                  {/* Date tag / Category */}
                  <div className="text-right">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                      dark ? "bg-lime-500/10 text-lime-400 border border-lime-500/20" : "bg-lime-500/10 text-lime-650 border border-lime-500/20"
                    }`}>
                      {activeReview.tag}
                    </span>
                    <p className="text-[10px] text-zinc-500 font-bold mt-0.5 uppercase">
                      {activeReview.date}
                    </p>
                  </div>
                </div>
              </div>

              {/* Arrows handles */}
              <div className="flex justify-end gap-2.5 mt-6" id="testi-nav-triggers">
                <button
                  onClick={handlePrev}
                  className={`p-2.5 rounded-lg border transition-all pointer-events-auto ${
                    dark
                      ? "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-300"
                      : "bg-black/5 border-black/10 hover:bg-black/10 text-zinc-700 shadow-sm"
                  }`}
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className={`p-2.5 rounded-lg border transition-all pointer-events-auto ${
                    dark
                      ? "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-300"
                      : "bg-black/5 border-black/10 hover:bg-black/10 text-zinc-700 shadow-sm"
                  }`}
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
