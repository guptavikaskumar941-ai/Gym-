import React, { useState } from "react";
import { MapPin, Phone, Mail, Clock, PhoneCall, MessageCircle, Send } from "lucide-react";
import { motion } from "motion/react";

interface ContactProps {
  dark: boolean;
  onSuccessToast: (msg: string) => void;
}

export default function Contact({ dark, onSuccessToast }: ContactProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "Free Trial Reservation",
    message: "",
  });
  const [loading, setLoading] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      alert("Please provide Name and Phone number to contact you!");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSuccessToast(
        `Thank you, ${formData.name}! Your inquiry concerning '${formData.subject}' has been recorded. Coach Vikram will call/WhatsApp you within 3 hours!`
      );
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "Free Trial Reservation",
        message: "",
      });
    }, 1200);
  };

  const businessPhone = "092076 64477";
  const whatsappUrl = "https://wa.me/919207664477?text=Hi%20FitBox%20Gym%20Bengaluru!%2520I%2520am%2520interested%2520in%2520booking%2520a%2520Free%2520Trial%2520session.";

  return (
    <section
      id="contact"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Connect With Us
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Get in Touch Instantly
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold mb-2 ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            We are situated opposite Krishna Leela Grand Hotel. Complete our digital ticket below for an immediate trial code, or trigger quick-actions to connect on call or WhatsApp.
          </p>
        </div>

        {/* Double Columns Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch" id="contact-main-grid">
          {/* Column Left: Contact Info details & Live Google Maps */}
          <div className="lg:col-span-5 flex flex-col gap-6 text-left">
            
            {/* Quick Details Card */}
            <div className={`p-6 sm:p-8 rounded-3xl border space-y-6 backdrop-blur-xl ${
              dark ? "bg-white/5 border-white/10 text-white" : "bg-black/5 border-black/10 shadow-sm text-zinc-900"
            }`}>
              <h3 className="font-sans text-lg font-black uppercase tracking-wide">
                FitBox Gym Bengaluru
              </h3>

              <div className="space-y-4">
                {/* Address Item */}
                <div className="flex items-start gap-3 text-xs sm:text-sm font-semibold">
                  <MapPin className={`w-5 h-5 flex-shrink-0 mt-0.5 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  <div>
                    <span className="block text-[10px] text-zinc-500 font-bold uppercase">PHYSICAL TURF ADDRESS</span>
                    <p className={`mt-0.5 leading-relaxed ${dark ? "text-zinc-300" : "text-zinc-650"}`}>
                      3rd H Main Rd, opposite Krishna Leela Grand Hotel, St Thomas Town, Kadugondanahalli, Bengaluru, Karnataka 560084
                    </p>
                  </div>
                </div>

                {/* Phone Item */}
                <div className="flex items-start gap-3 text-xs sm:text-sm font-semibold">
                  <Phone className={`w-5 h-5 flex-shrink-0 mt-0.5 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  <div>
                    <span className="block text-[10px] text-zinc-500 font-bold uppercase">PHONE / HOTLINE CONTROLS</span>
                    <p className={`mt-0.5 ${dark ? "text-zinc-350" : "text-zinc-705"}`}>092076 64477</p>
                  </div>
                </div>

                {/* Mail Item */}
                <div className="flex items-start gap-3 text-xs sm:text-sm font-semibold">
                  <Mail className={`w-5 h-5 flex-shrink-0 mt-0.5 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  <div>
                    <span className="block text-[10px] text-zinc-500 font-bold uppercase">DIGITAL CORRESPONDENCE</span>
                    <p className={`mt-0.5 ${dark ? "text-zinc-350" : "text-zinc-750"}`}>support@fitboxgymbengaluru.com</p>
                  </div>
                </div>

                {/* Timings Item */}
                <div className="flex items-start gap-3 text-xs sm:text-sm font-semibold">
                  <Clock className={`w-5 h-5 flex-shrink-0 mt-0.5 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  <div>
                    <span className="block text-[10px] text-zinc-500 font-bold uppercase">ACTIVE SESSIONS TIMINGS</span>
                    <p className={`mt-0.5 leading-relaxed ${dark ? "text-zinc-350" : "text-zinc-755"}`}>
                      Mon - Sat: 5:00 AM - 10:00 PM <br />
                      Sunday: 7:00 AM - 2:00 PM (flexible)
                    </p>
                  </div>
                </div>
              </div>

              {/* Direct Access Touch buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-zinc-200/50 dark:border-zinc-800/40" id="quick-links-triggers">
                {/* Call Now button */}
                <a
                  href={`tel:${businessPhone.replace(/\s/g, "")}`}
                  className="flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider bg-lime-500 hover:bg-lime-650 text-black flex items-center justify-center gap-2 transition"
                >
                  <PhoneCall className="w-4 h-4" />
                  Call Now
                </a>

                {/* WhatsApp button */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider bg-green-600 hover:bg-green-700 text-white flex items-center justify-center gap-2 transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </a>
              </div>
            </div>

            {/* Responsive Google Maps Embed frame with customized styling */}
            <div className={`rounded-3xl overflow-hidden border aspect-[16/10] bg-zinc-900 border-zinc-200/60 dark:border-zinc-850 shadow-sm relative group`} id="gmap-embed-frame">
              <iframe
                title="Google Maps Location for FitBox Gym Bengaluru"
                src="https://maps.google.com/maps?q=FitBox%20Gym,%203rd%20H%20Main%20Rd,%20opposite%20Krisha%20Leela%20Grand%20Hotel,%20Kadugondanahalli,%20Bengaluru,%20Karnataka%20560084&t=&z=15&ie=UTF8&iwloc=&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Column Right: Elegant Contact Inquiry Form panel */}
          <div className="lg:col-span-7">
            <div className={`p-6 sm:p-8 rounded-3xl border h-full text-left flex flex-col justify-between backdrop-blur-xl ${
              dark ? "bg-white/5 border-white/10 text-white" : "bg-black/5 border-black/10 shadow-sm text-zinc-900"
            }`}>
              <form onSubmit={handleInquirySubmit} className="space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-sans text-lg font-black uppercase tracking-wide mb-2">
                    Submit Digital Ticket
                  </h3>
                  <p className={`text-xs mb-6 font-semibold ${dark ? "text-zinc-400" : "text-zinc-650"}`}>
                    Our member relationship desk monitors incoming inquiries in real-time. Expect a custom callback to block structural trials shortly.
                  </p>

                  <div className="space-y-4">
                    {/* Name input */}
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-500">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Aniket Sen"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                          dark
                            ? "bg-black/30 border-white/10 text-white placeholder-zinc-500"
                            : "bg-white/40 border-black/10 text-zinc-905 placeholder-zinc-400"
                        }`}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Phone input */}
                      <div>
                        <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-500">
                          Phone / WhatsApp *
                        </label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. 092076 64477"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                            dark
                              ? "bg-black/30 border-white/10 text-white placeholder-zinc-500"
                              : "bg-white/40 border-black/10 text-zinc-905 placeholder-zinc-400"
                          }`}
                        />
                      </div>
                      
                      {/* Email input */}
                      <div>
                        <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-500">
                          Email Address
                        </label>
                        <input
                          type="email"
                          placeholder="e.g. aniket@domain.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 ${
                            dark
                              ? "bg-black/30 border-white/10 text-white placeholder-zinc-500"
                              : "bg-white/40 border-black/10 text-zinc-905 placeholder-zinc-400"
                          }`}
                        />
                      </div>
                    </div>

                    {/* Preferred Option Dropdown */}
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-500">
                        Inquiry Subject / Target Split
                      </label>
                      <select
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className={`w-full px-4 py-3.5 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 cursor-pointer ${
                          dark
                            ? "bg-black/30 border-white/10 text-white"
                            : "bg-white/40 border-black/10 text-zinc-905"
                        }`}
                      >
                        <option value="Free Trial Reservation">Book a 1-Day Free Trial Session</option>
                        <option value="Monthly Flex Inquiry">Subscribing for Monthly Flex</option>
                        <option value="Half Year Consultation">Subscribing for Half-Year (COMP PTs)</option>
                        <option value="Annual Performance Package">Elite Performance Annual (Best Val)</option>
                        <option value="Custom Diet Chart Guidance">Custom Nutrition Advice Questions</option>
                      </select>
                    </div>

                    {/* Message comments */}
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider mb-1 text-zinc-500">
                        Additional Messages / Body Goals
                      </label>
                      <textarea
                        rows={3}
                        placeholder="e.g. I want to schedule a free trial class under Vikram this Friday evening at 7:00 PM."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl text-sm font-semibold border focus:outline-none focus:ring-2 focus:ring-lime-500 resize-none ${
                          dark
                            ? "bg-black/30 border-white/10 text-white placeholder-zinc-500"
                            : "bg-white/40 border-black/10 text-zinc-905 placeholder-zinc-400"
                        }`}
                      />
                    </div>
                  </div>
                </div>

                {/* Submitting Trigger button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-6 py-4.5 rounded-xl font-black uppercase text-xs sm:text-sm tracking-widest bg-lime-500 hover:bg-lime-600 text-black shadow-xl shadow-lime-550/20 flex items-center justify-center gap-2 transition pointer-events-auto"
                >
                  {loading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      Logging Ticket...
                    </>
                  ) : (
                    <>
                      <Send className="w-4.5 h-4.5" />
                      Book My Free Trial Session Now
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
