import { useState } from "react";
import { faqData } from "../data";
import { HelpCircle, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface FAQProps {
  dark: boolean;
}

export default function FAQ({ dark }: FAQProps) {
  const [openFaqId, setOpenFaqId] = useState<string | null>("faq-1");

  const toggleFaq = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  return (
    <section
      id="faq"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Resolve Doubts
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Frequently Asked Questions
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Review commonly asked questions about locker rooms, active membership freeze credits, Bengaluru branch parking limits, and training hours below.
          </p>
        </div>

        {/* Accordions Container */}
        <div className="max-w-3xl mx-auto space-y-4" id="faq-accordions">
          {faqData.map((faq) => {
            const isOpen = openFaqId === faq.id;
            return (
              <div
                key={faq.id}
                className={`rounded-2xl border overflow-hidden transition-all duration-300 backdrop-blur-md ${
                  isOpen
                    ? dark
                      ? "bg-white/10 border-lime-400/30 shadow-lg shadow-lime-500/5"
                      : "bg-black/5 border-lime-550/30 shadow-lg"
                    : dark
                      ? "bg-white/5 border-white/5 hover:bg-white/10"
                      : "bg-black/5 border-black/5 hover:bg-black/10"
                }`}
              >
                {/* Accordion Trigger header */}
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 font-bold uppercase tracking-wide select-none pointer-events-auto"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className={`w-5 h-5 flex-shrink-0 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                    <span className={`text-xs sm:text-sm ${dark ? "text-white" : "text-zinc-900"}`}>
                      {faq.question}
                    </span>
                  </div>
                  {isOpen ? (
                    <ChevronUp className={`w-4.5 h-4.5 flex-shrink-0 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                  ) : (
                    <ChevronDown className="w-4.5 h-4.5 text-zinc-400 flex-shrink-0" />
                  )}
                </button>

                {/* Answer Collapsible Section */}
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className={`p-6 pt-0 text-left text-xs sm:text-sm leading-relaxed font-semibold border-t ${
                        dark
                          ? "text-zinc-300 border-white/10"
                          : "text-zinc-705 border-black/10"
                      }`}>
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
