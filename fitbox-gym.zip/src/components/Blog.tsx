import { useState } from "react";
import { blogPostsData } from "../data";
import { BlogPost } from "../types";
import { Calendar, User, Clock, ChevronRight, X, BookOpen, Share2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface BlogProps {
  dark: boolean;
}

export default function Blog({ dark }: BlogProps) {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  const openPostReader = (post: BlogPost) => {
    setSelectedPost(post);
  };

  const closePostReader = () => {
    setSelectedPost(null);
  };

  return (
    <section
      id="blog"
      className={`py-24 transition-colors duration-500 relative z-10 border-b ${
        dark ? "bg-black/30 border-white/5 backdrop-blur-md" : "bg-white/30 border-black/5 backdrop-blur-md"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-lime-400 font-bold uppercase tracking-widest text-xs">
            Physical Intellect
          </span>
          <h2 className={`font-sans text-3xl sm:text-5xl font-black uppercase mt-1 tracking-tight ${
            dark ? "text-white" : "text-zinc-900"
          }`}>
            Our Experts Journal
          </h2>
          <p className={`text-xs sm:text-sm mt-3 leading-relaxed font-semibold ${
            dark ? "text-zinc-400" : "text-zinc-650"
          }`}>
            Read our scientific reviews pertaining to heavy strength powerlifting complexes, high calorie fat oxidizing metabolic recipes, and local hyper-nutritive foods.
          </p>
        </div>

        {/* Blog layout cards matrix */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="blog-posts-grid">
          {blogPostsData.map((post) => (
            <article
              key={post.id}
              className={`rounded-2xl overflow-hidden border flex flex-col justify-between transition-all duration-350 backdrop-blur-xl ${
                dark ? "bg-white/5 border-white/10 hover:border-lime-400/30" : "bg-black/5 border-black/10 shadow-sm hover:border-lime-500/30"
              }`}
              id={`blog-card-${post.id}`}
            >
              <div>
                {/* Photo with overlay tag */}
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    referrerPolicy="no-referrer"
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Category label */}
                  <span className={`absolute bottom-3 left-3 px-2.5 py-1 rounded text-[9px] font-sans font-black uppercase tracking-widest shadow-sm ${
                    dark ? "bg-lime-500 text-black shadow-lime-500/10" : "bg-lime-650 text-white shadow-lime-650/10"
                  }`}>
                    {post.category}
                  </span>
                </div>

                {/* Description texts */}
                <div className="p-6 text-left">
                  {/* Row meta info */}
                  <div className="flex items-center gap-3.5 mb-3 text-[10px] text-zinc-500 font-bold uppercase tracking-wider">
                    <span className="flex items-center gap-1">
                      <Calendar className={`w-3.5 h-3.5 ${dark ? "text-lime-450" : "text-lime-600"}`} />
                      {post.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className={`w-3.5 h-3.5 ${dark ? "text-lime-450" : "text-lime-600"}`} />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className={`font-sans text-lg font-black uppercase mt-2 tracking-tight leading-snug hover:text-lime-400 transition-colors cursor-pointer ${
                    dark ? "text-white" : "text-zinc-900"
                  }`}
                  onClick={() => openPostReader(post)}
                  >
                    {post.title}
                  </h3>

                  <p className={`text-xs leading-relaxed mt-3 font-semibold ${
                    dark ? "text-zinc-400" : "text-zinc-650"
                  }`}>
                    {post.excerpt}
                  </p>
                </div>
              </div>

              {/* Actions Footer row */}
              <div className="p-6 pt-0 text-left">
                <button
                  onClick={() => openPostReader(post)}
                  className={`inline-flex items-center gap-1 text-xs font-black uppercase tracking-widest hover:gap-2.5 transition-all duration-300 pointer-events-auto ${
                    dark ? "text-lime-400" : "text-lime-605"
                  }`}
                >
                  <span>Read Complete Blueprint</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Dynamic Reader Overlay Modal box */}
        <AnimatePresence>
          {selectedPost && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6" id="blog-reader-display">
              {/* Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={closePostReader}
                className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              />

              {/* Frame Box */}
              <motion.div
                initial={{ opacity: 0, scale: 0.96, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96, y: -20 }}
                transition={{ type: "spring", damping: 25 }}
                className={`relative w-full max-w-2xl rounded-3xl p-5 sm:p-8 shadow-2xl z-10 border max-h-[85vh] overflow-y-auto ${
                  dark ? "bg-zinc-900 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-900"
                }`}
              >
                {/* Close Button Trigger top */}
                <button
                  onClick={closePostReader}
                  className={`absolute top-4 right-4 p-2.5 rounded-xl transition-colors ${
                    dark ? "hover:bg-zinc-800 text-zinc-450 hover:text-white" : "hover:bg-zinc-150 text-zinc-500 hover:text-zinc-900"
                  }`}
                  aria-label="Close reader"
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Reader Meta Details Header */}
                <div className="space-y-4 text-left pr-6">
                  <span className={`inline-block border px-3 py-1 rounded text-[10px] font-sans font-black uppercase tracking-widest ${
                    dark ? "bg-lime-500/10 text-lime-400 border-lime-400/20" : "bg-lime-500/10 text-lime-650 border-lime-650/20"
                  }`}>
                    {selectedPost.category}
                  </span>

                  <h3 className="font-sans text-xl sm:text-3xl font-black uppercase tracking-tight leading-tight">
                    {selectedPost.title}
                  </h3>

                  {/* Authors line */}
                  <div className="flex items-center flex-wrap gap-4 text-xs font-bold uppercase tracking-wider text-zinc-550 border-b border-zinc-200/50 dark:border-zinc-850/60 pb-4">
                    <span className="flex items-center gap-1">
                      <User className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                      By {selectedPost.author}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                      {selectedPost.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-600"}`} />
                      {selectedPost.readTime}
                    </span>
                  </div>
                </div>

                {/* Article photo spacer */}
                <div className="aspect-[16/9] w-full mt-6 rounded-2xl overflow-hidden shadow">
                  <img
                    referrerPolicy="no-referrer"
                    src={selectedPost.image}
                    alt={selectedPost.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Article texts prose */}
                <div className={`mt-8 text-left text-xs sm:text-sm font-medium leading-relaxed space-y-4 ${
                  dark ? "text-zinc-300" : "text-zinc-700"
                }`} id="blog-article-body">
                  {selectedPost.content.split("\n\n").map((para, pIdx) => {
                    // Simple bullet points parsing
                    if (para.startsWith("1. ") || para.startsWith("* ")) {
                      return (
                        <div key={pIdx} className="pl-2 space-y-2 font-bold uppercase tracking-wide">
                          {para.split("\n").map((li, lIdx) => (
                            <p key={lIdx} className="text-zinc-200 my-1 font-semibold leading-relaxed">
                              {li}
                            </p>
                          ))}
                        </div>
                      );
                    }
                    return <p key={pIdx}>{para}</p>;
                  })}
                </div>

                {/* Share action bar */}
                <div className="flex items-center justify-between mt-8 border-t border-zinc-200/50 dark:border-zinc-855/50 pt-5 text-xs font-bold text-zinc-500">
                  <div className="flex items-center gap-2">
                    <BookOpen className={`w-4 h-4 ${dark ? "text-lime-400" : "text-lime-650"}`} />
                    <span className="uppercase tracking-wider">Happy Recovery Lift!</span>
                  </div>
                  <button
                    onClick={() => alert("Copied dynamic post link to clipboard!")}
                    className="flex items-center gap-1.5 px-3.5 py-2 hover:bg-lime-500/10 hover:text-lime-450 border rounded-xl transition-all pointer-events-auto"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span className="uppercase tracking-wider">Share</span>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
