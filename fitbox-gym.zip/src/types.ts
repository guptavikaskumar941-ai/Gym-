export interface Trainer {
  id: string;
  name: string;
  role: string;
  certs: string[];
  experience: string;
  specializations: string[];
  image: string;
}

export interface MembershipPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  features: string[];
  highlighted: boolean;
  tag?: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: string;
  category: "Training" | "Program" | "Nutrition";
}

export interface WorkoutProgram {
  id: string;
  name: string;
  duration: string;
  intensity: "Beginner" | "Intermediate" | "Advanced";
  objective: string;
  description: string;
  schedule: {
    day: string;
    routine: string;
    exercises: string[];
  }[];
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  image: string;
  author: string;
  readTime: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface TestimonialReview {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
  tag: string;
}
